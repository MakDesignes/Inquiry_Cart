<?php
 $root =  $_SERVER['DOCUMENT_ROOT'];
//$root =  $_SERVER['DOCUMENT_ROOT'];
include('config.ini.php');
include('function.ini.php');
include('smart_resize_image.function.php');
$dbconn = conn($config['DB_HOST'],$config['DB_USER'],$config['DB_PASS'],$config['DB']);
require_once('sdk/geoplugin.class/geoplugin.class.php');
$ip = getRealIpAddr();
//$root = dirname(__file__);
// if database ok then run this code
if ($dbconn == TRUE) {
// now the check that is user is login?	
if (is_log_in() == true) {
	/*this is page loading function */
	if (isset($_GET['p'])) {
		$pge=$_GET['p'];
	}else{
		$pge = false;
	}
	page($pge,$root);	
}else{
	// else if not login
	if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['LOGIN'])) {
		# LOGIN CODE GOESE HERE
		$user = mysql_real_escape_string($_POST['username']);
		$pass = md5(mysql_real_escape_string($_POST['password']));
		$login = login($user,$pass,$dbconn);
		if ($login  == true) {
			add_ip_indb($ip);
			require('include/main/header.ini.php');
			include('include/dashboard.php');
			include('include/main/footer.ini.php');
		}else{
			$msg = "error";
			include('include/login.php');
		}
	}else{
		include('include/login.php');
	}
	
}
// else if does not run dtabase then go to install page
}else{
	//header('Location:install.php');
}
