<?php
@session_start();
$config = array(
		'DB_HOST' => 'localhost',
 		'DB_USER' => 'root',
 		'DB_PASS' => '',
 		'DB'=>'git-moto',
 		'UNINUM'=>'12312345');
@define('DB_PREFIX' , 'CD_');
mysql_connect($config['DB_HOST'], $config['DB_USER'], $config['DB_PASS'])or die("cannot connect");
mysql_select_db($config['DB']);
$data_admin = mysql_fetch_array(mysql_query("SELECT * FROM `admin`"));
@$data_seo = mysql_fetch_array(mysql_query("SELECT * FROM `seo`"));
$data_past = mysql_fetch_array(mysql_query("SELECT * FROM `other_setting`"));
@define('BASE_URL', $data_admin['web']);