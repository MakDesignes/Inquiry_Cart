</div><!--content-->
              
            </div><!--maincontentinner-->
<div class="footer">
            	<p>Design Markaz &copy; <?php echo date('Y') ?>. All Rights Reserved. Poewr by: <a href="http://designmarkaz.com">Design Markaz</a></p>
            </div><!--footer-->
            
        </div><!--maincontent-->
        
                
     	</div><!--mainwrapperinner-->
    </div><!--mainwrapper-->
	<!-- END OF MAIN CONTENT -->
    

</body>


</html>