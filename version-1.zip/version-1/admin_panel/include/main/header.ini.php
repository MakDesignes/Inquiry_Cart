<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>MAK Designes Admin Panel</title>
<link rel="stylesheet" href="<?php echo BASE_URL ?>admin_panel/css/style.css" type="text/css" />
<!--[if IE 9]>
    <link rel="stylesheet" media="screen" href="css/ie9.css"/>
<![endif]-->

<!--[if IE 8]>
    <link rel="stylesheet" media="screen" href="css/ie8.css"/>
<![endif]-->

<!--[if IE 7]>
    <link rel="stylesheet" media="screen" href="css/ie7.css"/>
<![endif]-->
<script type="text/javascript" src="<?php echo BASE_URL ?>admin_panel/js/plugins/jquery-1.7.min.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL ?>admin_panel/js/plugins/jquery.flot.min.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL ?>admin_panel/js/plugins/jquery.flot.resize.min.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL ?>admin_panel/js/plugins/jquery-ui-1.8.16.custom.min.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL ?>admin_panel/js/custom/general.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL ?>admin_panel/js/custom/dashboard.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL ?>admin_panel/js/plugins/jquery.dataTables.min.js"></script>
<script  src="<?php echo BASE_URL ?>admin_panel/plugins/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL ?>admin_panel/js/custom/tables.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL ?>admin_panel/js/plugins/jquery.flot.min.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL ?>admin_panel/js/plugins/jquery.flot.pie.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL ?>admin_panel/js/plugins/jquery.flot.resize.min.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL ?>admin_panel/js/plugins/jquery-ui-1.8.16.custom.min.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL ?>admin_panel/js/custom/charts.js"></script>
<!--[if lt IE 9]>
	<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
<![endif]-->
<script type="text/javascript">
tinymce.init({
    selector: "textarea#body",
    theme: "modern",
    plugins: [
         "advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker",
         "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
         "save table contextmenu directionality emoticons template paste textcolor responsivefilemanager"
   ],
   toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | print preview media fullpage | forecolor backcolor emoticons| responsivefilemanager", 
   external_filemanager_path:"<?php echo BASE_URL ?>admin_panel/plugins/filemanager/", filemanager_title:"Responsive Filemanager" , external_plugins: { "filemanager" : "<?php echo BASE_URL ?>admin_panel/plugins/filemanager/plugin.min.js"},
   
 }); 

</script>

</head>
 <?php 

$chackStatusQ=mysql_query("SELECT * FROM `site_stat`");
    $chackStatusQf=mysql_fetch_assoc($chackStatusQ);
    if ($chackStatusQf['under_status'] == 1) {
        echo '<div style="height:40px;background:#FF0303;font-family: Arial, Helvetica, sans-serif;
font-size: 12px;-webkit-box-shadow: 0 1px 0 #444;
height:50px;
 box-shadow: 0px 1px 50px #5E5E5E;
 top:0px;
color: #fff;text-align:center"><h1 style="padding-top: 11px;font-family: "BebasNeueRegular", Arial, Helvetica, sans-serif;
letter-spacing: 0.5px;
font-weight: normal;
color:#DD2424 !important;">under construction mode On</h1></div>';
    } ?> 
<body class="loggedin">

	<!-- START OF HEADER -->
	<div class="header radius3">
    	<div class="headerinner">
        	
            <a href="<?php echo BASE_URL ?>"><img src="<?php echo BASE_URL ?>admin_panel/images/starlight_admin_template_logo_small.png" alt="" style="width: 165px;"/></a>
            
              
            <div class="headright">
            	<div class="headercolumn">&nbsp;</div>
            	<div id="searchPanel" class="headercolumn">
                	<div class="searchbox">
                        <form action="product-detail" method="post">
                            <input type="text" id="keyword" name="art" class="radius2" value="Search here" /> 
                        </form>
                    </div><!--searchbox-->
                </div><!--headercolumn-->
            	<div id="notiPanel" class="headercolumn">
                    <div class="notiwrapper">
                        <a href="" class="notialert radius2"><?php echo mysql_num_rows(mysql_query("SELECT * FROM `inquiry`")); ?></h1></a>
                   
                    </div><!--notiwrapper-->
                </div><!--headercolumn-->
                <div id="userPanel" class="headercolumn">
                    <a href="#" class="userinfo radius2">
                        <img src="images/avatar.png" alt="" class="radius2" />
                        <span><strong> <?php echo  $_SESSION['admin'] ?></strong> </span>
                    </a>
                    <div class="userdrop">
                        <ul>
                            
                            <li><a href="account">Account Settings</a></li>

                         <!--   <li><a href="web-setting">Website Settings</a></li> -->
                            <li><a href="<?php echo BASE_URL ?>admin_panel/logout.php">Logout</a></li>
                        </ul>
                    </div><!--userdrop-->
                </div><!--headercolumn-->
            </div><!--headright-->
        
        </div><!--headerinner-->
	</div><!--header-->
    <!-- END OF HEADER -->
        
    <!-- START OF MAIN CONTENT -->
    <div class="mainwrapper">
     	<div class="mainwrapperinner">
         	
        <div class="mainleft">
          	<div class="mainleftinner">
            
              	<div class="leftmenu">
            		<ul>
                    	<li><a href="dashboard" class="dashboard" ><span>Dashboard</span></a></li>
                    	<li><a href="manage-product-catagory" class="buttons" ><span>Manage Links</span></a></li>
                        <li><a href="inqueries" class="buttons" ><span>Manage Inqueries</span></a></li>   
                        <li><a href="slider" class="buttons" ><span>Manage Sliders</span></a></li> 
                        <li><a href="seo" class="buttons" ><span>Seo</span></a></li>
                        <li><a href="page" class="buttons" ><span>Pages</span></a></li>
                        <li><a href="manage-links" class="buttons" ><span>Nav</span></a></li>   
                        <li><a href="country-blocker" class="buttons" ><span>Country Blocker</span></a></li>   
                        <li><a href="extra-setting" class="buttons" ><span>Extra site setting</span></a></li>                        
                    	<li><a href="manage-products" class="media"><span><em>Manage Products</em></span></a></li>
<!--                     	<li><a href="<?php echo BASE_URL?>admin_panel/plugins/filemanager/dialog.php?type=0" class="file" ><span>File manager</span></a></li>
 -->                       <!-- <li><a href="chat/php/app.php/login" class="chat"><span><em>Chat Support</em></span></a></li> -->
                    </ul>
                        
                </div><!--leftmenu-->
            	<div id="togglemenuleft"><a></a></div>
            </div><!--mainleftinner-->
        </div><!--mainleft-->
                <div class="maincontent noright">
            <div class="maincontentinner">
                
                <ul class="maintabmenu">
                    <li class="current"><a href="<?php echo isset($_GET['p'])?$_GET['p']:'';?>"><?php echo isset($_GET['p'])?$_GET['p']:"Dashboard";?></a></li>
                </ul><!--maintabmenu-->
                
                <div class="content">
                <!-- Start contanner -->