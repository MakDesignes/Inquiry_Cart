<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['delete'])) {
   $BID = $_POST['BID'];
   $cprds_rs = mysql_query("SELECT * FROM `slider` WHERE `id` = '$BID'");
$cprds = mysql_fetch_array($cprds_rs);
if ((".../source/sliders/".$cprds['img'])) {
    @unlink('../source/sliders/'.$cprds['img']);
}
if ((".../source/sliders/small_".$cprds['img'])) {
   @ unlink('../source/sliders/small_'.$cprds['img']);
}

$result = mysql_query("DELETE FROM `slider` WHERE `id` = '$BID'") or die(mysql_error());
   if ($result == TRUE) {
       # code...
    $msg =  '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p>Your Banner Deleted Sucessfully.</p>
                    </div>';
   }else{
    $msg = '<b>'. mysql_error().'</b>';
   }
} ?>
 <?php echo isset($msg)?$msg:'' ?>
<a href="add-slider"><button class="stdbtn btn_lime" style="float: right; display: block; opacity: 1;">ADD NEW BANNER</button></a>
                 <?php
                    $client_site=mysql_query("SELECT * FROM `slider`");
                    if(mysql_num_rows($client_site)<1){
                        echo '<center><h2>No Banner Found!</h2></center>';
                    }else{
                    
                    ?>
                    <div class="contenttitle radiusbottom0">
                    <h2 class="table"><span>Banner Quick Action</span></h2>
                </div><!--contenttitle-->   
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable dashtable">
                    <colgroup>
                        <col class="con0" />
                        <col class="con1" />
                        <col class="con0" />
                        <col class="con1" />
                        <col class="con0" />
                        <col class="con1" />
                    </colgroup>
                    <thead>
                        <tr>
                             <th class="head1">Banner Image</th>
                            <th class="head0">Title</th>
                            <th class="head1">Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                           <th class="head1">Banner Image</th>
                            <th class="head0">Title</th>
                            <th class="head1">Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                   <?php
                   while($clientsite=mysql_fetch_array($client_site)){
                       
                   
                   ?>
                        <tr>
                            <td class="center"><img src="../source/sliders/small_<?php echo $clientsite['img']; ?>" width="300" height="50" /></td>
                            <td class="center"><?php echo $clientsite['altname']; ?></td>
                            <td class="center">
                            <form method="post">
                                <input type="hidden" name="BID" value="<?php echo $clientsite['id']; ?>">
                                <input type="submit" name="delete" value="DELETE">
                            </form>
                            
                            </td>
                        </tr>
                     <?php } ?>
                    </tbody>
                </table>

                 <?php } ?>   