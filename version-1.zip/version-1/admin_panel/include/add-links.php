<?php
                    if ($_SERVER['REQUEST_METHOD']  == 'POST' AND isset($_REQUEST['SUBMIT'])) {
                        $name=$_REQUEST['name'];
                        $parent=$_REQUEST['parent'];
                        $show=$_REQUEST['show'];
                        $page=$_REQUEST['page'];
                        $query=mysql_query("INSERT INTO `links`(`id`, `linksname`, `parent`, `show`, `pageod`) VALUES (NULL,'$name','$parent','$show','$page')");
                        if ($query == true) {
                            echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>New header link added sucessfully. <a href="manage-links">Click</a> for manege header links</b></p>
                    </div>';
                         
                        }else{
                            echo mysql_error();
                        }
                    }
?>
                    <form  class="stdform stdform2" id="banner" method="post" action="" enctype="multipart/form-data">
                    
                            
                      
                                
                                <p>
                                    <label>Link Name</label>
                                    <span class="field"><input type="text" name="name" class="longinput"/></span>
                                </p>
                                 <p>
                                    <label>Parent</label>
                                    <span class="field">
                                    <select name="parent" class="longinput">
                                        <option value="0">Please Select</option>
                                        <?php  
                                        $link = mysql_query("select * from links");
                                        while ( $linkvar = mysql_fetch_object($link)) {
                                        ?>
                                        <option value="<?php echo $linkvar->id; ?>"><?php echo $linkvar->linksname; ?></option>
                                        <?php }  ?>
                                    </select>
                                    </span>
                                </p>
                                 <p>
                                    <label>Show</label>
                                    <span class="field"><input type="text" name="show" class="longinput" placeholget="0 mean no 1 mean yes"/></span>
                                </p>
                                 <p>
                                    <label>Page</label>
                                    <span class="field">
                                    <select name="page" class="longinput">
                                        <option value="0">Please Select</option>
                                        <?php  
                                        $page = mysql_query("select * from page");
                                        while ( $var = mysql_fetch_object($page)) {
                                        ?>
                                        <option value="<?php echo $var->id; ?>"><?php echo $var->pagename; ?></option>
                                        <?php }  ?>
                                    </select>
                                    </span>
                                </p>
                                <p>
                                    <label></label>
                                    <span class="field">
                
                
                
                             <button type="submit" class="stdbtn btn_black" style="opacity: 1;" name="SUBMIT">Add Now</button>
                            <input type="reset" class="reset radius2" value="Reset" /></span>
                                </p>
                               
                           

                    </form>
