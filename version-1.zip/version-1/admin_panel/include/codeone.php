<?php 
echo htmlentities(substr(time(),2));
 ?>