<?php
                  if (isset($_REQUEST['SUBMIT'])) {
                     $id=mysql_real_escape_string($_REQUEST['id']);
                    $fname=mysql_real_escape_string($_REQUEST['fname']);
                    $lname=mysql_real_escape_string($_REQUEST['lname']);
                    $email=mysql_real_escape_string($_REQUEST['email']);
                    $website=mysql_real_escape_string($_REQUEST['website']);
                    $about=mysql_real_escape_string($_REQUEST['aboutyou']);
                    $username=mysql_real_escape_string($_REQUEST['username']);
                    $password=mysql_real_escape_string($_REQUEST['password']);
                    $address=mysql_real_escape_string($_REQUEST['address']);
                    $mobile=mysql_real_escape_string($_REQUEST['mobile']);
                    $fax=mysql_real_escape_string($_REQUEST['fax']);
                    $user_pass=mysql_real_escape_string(md5($_REQUEST['password']));
                    $fb=mysql_real_escape_string($_REQUEST['fb']);
                    $fl=$_REQUEST['fl'];
                    $gp=$_REQUEST['gp'];
                    $tw=$_REQUEST['tw'];
                    $pt=$_REQUEST['pt'];

                    $query=mysql_query("UPDATE `admin` SET `email`= '$email',`password`='$user_pass',`back_pass`='$password',`user`='$username',`web`='$website',`about_you`='$about',`fname`='$fname',`lname`='$lname',`address`= '$address',`mobile`= '$mobile',`fax`= '$fax' , `fb`='$fb',`tw`='$tw',`fl`='$fl',`gp`='$gp',`pt`='$pt' WHERE id='$id'");
                    
                    if($query == true){

                         echo '<div class="notification msg success">
                        <a class="close"></a>
                        <p><b>Update data successfully</b></p>
                    </div>';
                        
                        
                    }else{
                        echo "<h1>Error! with updating data <a href='account.php'>goback</a></h1>";
                    }
                  }
                    
                    
                    ?>
  <form  class="stdform stdform2" method="post">
                    
                            
                       <?php
                       $get_userv=mysql_query("SELECT * FROM `admin`");
                       while($get_user=mysql_fetch_assoc($get_userv)){
                           extract($get_user);
                       
                       ?>
                            
                                <p>
                                    <label>First Name</label>
                                    <span class="field"><input type="text" name="fname" class="longinput" maxlength="40" value="<?php echo $fname; ?>"/></span>
                                </p>
                                <p>
                                    <label>Last Name</label>
                                    <span class="field"><input type="text" name="lname" class="longinput" maxlength="40" value="<?php echo $lname; ?>"/></span>
                                </p>
                                <p>
                                    <label>E-mail</label>
                                    <span class="field"><input type="text" name="email" class="longinput" maxlength="40" value="<?php echo $email; ?>"/></span>
                                </p>
                                <p>
                                    <label>Your Mobile Number</label>
                                    <span class="field"><input type="text" name="mobile" class="longinput" maxlength="40" value="<?php echo $mobile; ?>"/></span> 
                                </p>
                                <p>
                                    <label>Your Fax Number</label>
                                    <span class="field"><input type="text" name="fax" class="longinput" maxlength="40" value="<?php echo $fax; ?>"/></span> 
                                </p>
                                <p>
                                    <label>Username</label>
                                    <span class="field"><input type="text" name="username" class="longinput" maxlength="40" value="<?php echo $user; ?>"/></span>
                                </p>
                                <p>
                                    <label>Password</label>
                                    <span class="field"><input type="text" name="password" class="longinput" maxlength="40" value="<?php echo $back_pass; ?>"/></span>
                                </p>
                                 <p>
                                    <label>Website Name</label>
                                    <span class="field"><input type="text" name="website" class="longinput" maxlength="40" value="<?php echo $web; ?>"/><input type="hidden" name="id" value="<?php echo $id; ?>" /></span>
                                </p>
                                                                 <p>
                                    <label>facebook address</label>
                                    <span class="field"><input type="text" name="fb" class="longinput"  value="<?php echo $fb; ?>"/></span>
                                </p>
                                                                 <p>
                                    <label>twitter addtess</label>
                                    <span class="field"><input type="text" name="tw" class="longinput"  value="<?php echo $tw; ?>"/></span>
                                </p>
                                                                 <p>
                                    <label>Google+ Address</label>
                                    <span class="field"><input type="text" name="gp" class="longinput"  value="<?php echo $gp; ?>"/></span>
                                </p>
                                                                 <p>
                                    <label>Flicker Address</label>
                                    <span class="field"><input type="text" name="fl" class="longinput"  value="<?php echo $fl; ?>"/></span>
                                </p>
                                                                 <p>
                                    <label>pintrst Address</label>
                                    <span class="field"><input type="text" name="pt" class="longinput"  value="<?php echo $pt; ?>"/></span>
                                </p>
                                <p>
                                    <label>About you and website</label>
                                    <span class="field"><textarea cols="80" rows="5" class="longinput"  name="aboutyou" ><?php echo $about_you; ?></textarea></span> 
                                </p>
                                 <p>
                                    <label>Type Your Company Address</label>
                                    <span class="field"><textarea cols="80" rows="5" class="longinput"  name="address" ><?php echo $address; ?></textarea></span> 
                                </p>
                                
                                <?php } ?>
                                <p>
                                    <label></label>
                                    <span class="field">
                                    <button type="submit" class="stdbtn btn_black" style="opacity: 1;" name="SUBMIT">Update Setting</button>

                                   
                            <input type="reset" class="reset radius2" value="Reset" /></span>
                                </p>
                               
                           

                    </form>