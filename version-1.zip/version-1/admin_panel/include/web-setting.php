                <?php
                    if (isset($_REQUEST['SUBMIT'])) {
                        //this is a seo update script
                    $id=mysql_real_escape_string($_REQUEST['id']);
                    $site_state=mysql_real_escape_string($_REQUEST['site_state']);
                    $heading=mysql_real_escape_string($_REQUEST['heading']);
                    $msg=mysql_real_escape_string($_REQUEST['msg']);
                   


                    $query=mysql_query("UPDATE `site_stat` SET `under_status`='$site_state',`under_heading`='$heading',`under_message`='$msg' WHERE  id='$id'");
                    
                    if($query == true){

                       echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>Update data successfully</b></p>
                    </div>';
                        
                        
                    }else{
                        echo "<h1>Error! with updating data</h1>";
                    }
                    }
                
                    
                    ?>
               <form  class="stdform stdform2" method="post" >
                    
                            
                       <?php
                       $get_userv=mysql_query("SELECT * FROM `site_stat`");
                       while($get_user=mysql_fetch_assoc($get_userv)){
                           extract($get_user);
                       
                       ?>
                            
                                <p>
                                    <label>Website status</label>
                                    <span class="field">
                                                                     <?php 
                                            if ($under_status == 1) {
                                                echo '<input type="radio" name="site_state" value="0"> under construction mode Off<br><br>';
                                                echo '<input type="radio" name="site_state" checked value="1"> under construction mode On  ';
                                            }else{
                                                 echo '<input type="radio" name="site_state" checked value="0"> under construction mode off<br><br>';
                                                echo '<input type="radio" name="site_state" value="1"> under construction mode On  ';
                                            }
                                         ?>

                                        </span>
                                </p>
                                <p>
                                    <label>Heading</label>
                                    <span class="field"><input class="mediuminput" type="text" name="heading" value="<?php echo($under_heading) ?>"></span>
                                </p>
                                <p>
                                    <label>Message</label>
                                    <span class="field"><textarea class="longinput" name="msg" rows="5" cols="80"><?php echo($under_message) ?></textarea></span>
                                </p>
                                <input type="hidden" name='id' value="<?php echo($id) ?>"> 
                                <?php } ?>
                                <p>
                                    <label></label>
                                    <span class="field"><button type="submit" class="stdbtn btn_black" style="opacity: 1;" name="SUBMIT">Update Setting</button>
                            <input type="reset" class="reset radius2" value="Reset" /></span>
                                </p>
                               
                           

                    </form>