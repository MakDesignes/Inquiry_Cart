<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['delete'])) {
   $HID = $_POST['ID'];
   $result = del_main_cat($HID);
   if ($result == TRUE) {
       # code...
    $msg =  '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p>Your Footer Link Deleted Sucessfully.</p>
                    </div>';
   }else{
    $msg = '<b>'. mysql_error().'</b>';
   }
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['order'])) {
  $HID = $_POST['mid'];
  $ORD = $_POST['sorting_order'];
   $Updateq = mysql_query("UPDATE main_cats set sorting_order= '$ORD' WHERE main_cat_id = '$HID'");
   if ($Updateq == TRUE) {
       # code...
    $msg =  '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p>Your Footer Link Order Updated Sucessfully.</p>
                    </div>';
   }else{
    $msg = '<b>'. mysql_error().'</b>';
   }
}
 ?>
  <?php echo isset($msg)?$msg:'' ?>
<ul class="maintabmenu">
<!--                      <li><a href="manage-links" >Header Menu</a></li>
                    <li><a href="manage-footer-links">Footer Menu</a></li> -->
                    <li class="current"><a href="manage-product-catagory">Product Catagory</a></li>
 </ul><!--maintabmenu-->

<div class="content">

                   <div id="calendar"></div>  
                   <a href="add-main-cat"><button class="stdbtn btn_lime" style="float:right">ADD NEW CATAGORY</button></a>
                   <?php
                    $maincats_rs = mysql_query("select * from main_cats order by sorting_order");
                    $total_record=mysql_num_rows($maincats_rs);
                    if ($total_record == 0) {
                       echo '<h1>No Catagory Found!</h1>';
                    }else{
                    
                      
                    
                    ?>
                     <div class="contenttitle radiusbottom0">
                    <h2 class="table"><span>new,Edit & delete Catagory Menu</span></h2>
                </div><!--contenttitle-->  
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                    <colgroup>
                        <col class="con0" />
                        <col class="con1" />
                        <col class="con0" />
                        <col class="con1" />
                        <col class="con0" />
                    </colgroup>
                    <thead>
                        <tr>
                            
                            <th class="head1">Menu Name</th>
                            <th class="head0">Sorting Order</th>
                            <th class="head1">Update Sorting Order</th>
                            <th class="head0">Sub Catagory</th>
                            <th class="head0">Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                    
                        <tr>
                            
                            <th class="head1"></th>
                            <th class="head0"></th>
                            <th class="head1"></th>
                            <th class="head1"></th>
                            <th class="head0"></th>
                        </tr>
                    </tfoot>
                    <tbody>
                    <?php 
while($maincats = mysql_fetch_array($maincats_rs)){
                     ?>
                      <tr>  
                            <td class="center"><?php echo $maincats['caption']?></td>
                            <td class="center"><?php echo $maincats['sorting_order']?></td>
                            <td class="center"><form action="" method="post">
    <input type="text" size="2" name="sorting_order" value="<?php echo $maincats['sorting_order']?>"  /> 
    <input type="hidden"  name="mid" value="<?php echo $maincats['main_cat_id']?>" />
    <input type="submit" value="Update" name="order" style="background-color:#333333; color:#FFFFFF; width:auto; padding-left:15px; padding-right:15px;" />
    </form></td>
                            <td class="center">
                            <form action="sub-cat" method="post"><input type="hidden" name="ID" value="<?php echo $maincats['main_cat_id']?>"><button type="submit" class="stdbtn btn_red">Sub Crtagory</button></form>
                            </td>
                            <td class="center">
                            <form action="edit-main-cat" method="post">
                            <input type="hidden" name="ID" value="<?php echo $maincats['main_cat_id']?>">
<input type="submit" name="edit" class="btn btn3 btn_trash" style="background-color: rgb(247, 247, 247);background: none;border: none;color: #666;" value="Edit" ></form></form><form method="post"><input type="hidden" name="ID" value="<?php echo $maincats['main_cat_id']?>"><input type="submit" name="delete" class="btn btn3 btn_trash" style="background-color: rgb(247, 247, 247);background: none;border: none;color: #666;" value="Delete" ></form>                        
                             </td>
                        </tr>
                        <?php } ?>
                   </tbody>
                </table>
<?php } ?>

					</div><!--#tabs-->