<?php 
if (isset($_REQUEST['ID'])) {
   $_SESSION['ID'] = $_REQUEST['ID'];
   $id = $_SESSION['ID'];
}else{
    if (isset($_SESSION['ID'])) {
        $id = $_SESSION['ID'];
    }
}
$id;
if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['SUBMIT'])) {
    # code...
     $caption = mysql_real_escape_string($_REQUEST['caption']);
     $desired_dir="../source/images";

       
                    $sorting_order = mysql_real_escape_string($_REQUEST['sortind_order']);
                    if(empty($caption)){
                        echo '<div class="notification msgerror">
                        <a class="close"></a>
                        <p>Please fill all fields</p>
                    </div>';
                        
                    }else{

        if (empty($_FILES['files']['name'])) {
             $nwe_man=mysql_query("UPDATE `main_cats` SET `caption`='$caption',`sorting_order`='$sorting_order' WHERE `main_cat_id` = '$id'");
        
         # code...
     }else{
        $file_name = $_FILES['files']['name'];
        $file_tmp = $_FILES['files']['tmp_name'];
        move_uploaded_file($file_tmp,"$desired_dir/".$file_name);
        $nwe_man=mysql_query("UPDATE `main_cats` SET `caption`='$caption',`sorting_order`='$sorting_order',`img`='$file_name' WHERE `main_cat_id` = '$id'");
       
     }
                    if($nwe_man){
                         echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p>Your Link has been sucessfully updated.<a href="manage-product-catagory">Click</a> manage for products Catagory.</p>
                    </div>';
                    
                    }else{
                        mysql_error();
                    }
                    
                    }
}

                    
?>
<form class="stdform" action="" method="post" enctype="multipart/form-data">

<?php  $data = mysql_query("SELECT * FROM `main_cats` WHERE `main_cat_id` = '$id'");
    $data_new = mysql_fetch_assoc($data);
?>
                        
                        <p>
                            <label>Main Catagory</label>
                            <span class="field"><input type="text" name="caption" class="smallinput" value="<?php echo $data_new['caption']; ?>" /></span>
                            <small class="desc">Menu Name Here.</small>
                        </p>
                        <p>
                            <label>Main Catagory Image</label>
                            <span class="field"><input type="file" name="files" class="smallinput"  /></span>
                            <small class="desc">Menu Name Here.</small>
                        </p>
                     <p>
                            <label>Sorting Order</label>
                            <span class="field">
                            <select name="sortind_order"  size="1">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                </select></span>
                            <small class="desc">Small description of this field.</small>
                        </p>
                        
                       
                        <p class="stdformbutton">
                            <button type="submit" class="stdbtn btn_black" style="opacity: 0.75;" name="SUBMIT">update Now</button>
                            <input type="reset" class="reset radius2" value="Reset"  />
                        </p>
                        
                        
                    </form>
