<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['delete'])) {
   $HID = $_POST['ID'];
   $result = mysql_query("DELETE FROM `footer_menu` WHERE `id`='$HID'");
   if ($result == TRUE) {
       # code...
    $msg =  '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p>Your Footer Link Deleted Sucessfully.</p>
                    </div>';
   }else{
    $msg = '<b>'. mysql_error().'</b>';
   }
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['order'])) {
  $HID = $_POST['uniid'];
  $ORD = $_POST['sorting_order'];
   $Updateq = mysql_query("UPDATE `footer_menu` SET `order`='$ORD' WHERE `id`='$HID'");
   if ($Updateq == TRUE) {
       # code...
    $msg =  '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p>Your Footer Link Order Updated Sucessfully.</p>
                    </div>';
   }else{
    $msg = '<b>'. mysql_error().'</b>';
   }
}
 ?>
 <?php echo isset($msg)?$msg:'' ?>
<ul class="maintabmenu">
                     <li ><a href="manage-links" >Header Menu</a></li>
                    <li class="current"><a href="manage-footer-links">Footer Menu</a></li>
                    <li><a href="manage-product-catagory">Product Catagory</a></li>
                </ul><!--maintabmenu-->
                
                <div class="content">
                   <a href="add-footer-links"><button class="stdbtn btn_lime" style="float: right; display: block; opacity: 1;">ADD NEW FOOTER LINK</button></a>
                 <?php
                    $client_site=mysql_query("SELECT * FROM `footer_menu`");
                    if(mysql_num_rows($client_site)<1){
                        echo '<center><h2>No Footer Menu Link Found!</h2></center>';
                    }else{
                    
                    ?>
                    <div class="contenttitle radiusbottom0">
                    <h2 class="table"><span>new,Edit & delete header Menu</span></h2>
                </div><!--contenttitle-->   
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable dashtable">
                    <colgroup>
                        <col class="con0" />
                        <col class="con1" />
                        <col class="con0" />
                        <col class="con1" />
                        <col class="con0" />
                        <col class="con1" />
                    </colgroup>
                    <thead>
                        <tr>
                            
                            <th class="head0">Link Title</th>
                            <th class="head1">Sorting Order</th>
                            <th class="head0">Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                           
                            <th class="head0">Link Title</th>
                            <th class="head1">Sorting Order</th>
                            <th class="head0">Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                   <?php
                   while($clientsite=mysql_fetch_object($client_site)){
                       
                   
                   ?>
                        <tr>
                            <td class="center"><?php echo $clientsite->name; ?></td>
                            <td class="center">
                                <form action="" method="post">
    <input type="text" size="2" name="sorting_order" value="<?php echo $clientsite->order; ?>"  /> 
    <input type="hidden"  name="uniid" value="<?php echo $clientsite->id; ?>" />
    <input type="submit" value="Update" name="order" style="background-color:#333333; color:#FFFFFF; width:auto; padding-left:15px; padding-right:15px;" />
    </form>
                                </td>
                            <td class="center"><form action="up-footer-links" method="post"><input type="hidden" name="ID" value="<?php echo $clientsite->id; ?>"><input type="submit" name="edit" class="btn btn3 btn_trash" style="background-color: rgb(247, 247, 247);background: none;border: none;color: #666;" value="Edit" ></form></form><form method="post"><input type="hidden" name="ID" value="<?php echo $clientsite->id; ?>"><input type="submit" name="delete" class="btn btn3 btn_trash" style="background-color: rgb(247, 247, 247);background: none;border: none;color: #666;" value="Delete" ></form></td>
                        </tr>
                     <?php } ?>
                    </tbody>
                </table>

                 <?php } ?>   
