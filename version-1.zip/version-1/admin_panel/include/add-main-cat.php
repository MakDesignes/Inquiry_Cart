<?php if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    # code...
     $caption = mysql_real_escape_string($_REQUEST['caption']);
                    $sorting_order = mysql_real_escape_string($_REQUEST['sortind_order']);
                    if(empty($caption)){
                        echo '<div class="notification msgerror">
                        <a class="close"></a>
                        <p>Please fill all fields</p>
                    </div>';
                        
                    }else{

                    $nwe_man=mysql_query("INSERT INTO `main_cats`(`main_cat_id`, `caption`, `sorting_order`) VALUES ('','$caption','$sorting_order')");
                    if($nwe_man == TRUE){
                         echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p>New Catagory added sucessfully.<a href="manage-product-catagory">Click</a> manage for products Catagory.</p>
                    </div>';
                    
                    }else{
                        mysql_error();
                    }
                    
                    }
}

                    
?>
<form class="stdform" action="" method="post">
                        
                        <div class="form-group">
                            <label>Main Catagory</label>
                            <span class="field"><input type="text"  class="form-control" name="caption" class="smallinput" required="required" /></span>
                            <small class="desc">Menu Name Here.</small>
                        </div>
                        
                    <div class="form-group">
                            <label>Sorting Order</label>
                            <span class="field">
                            <select name="sortind_order"   class="form-control" size="1">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                </select></span>
                            <small class="desc">Small description of this field.</small>
                        </div>
                        
                       
                      <div class="form-group">
                            <button type="submit" class="stdbtn btn_black" style="opacity: 0.75;" name="SUBMIT">Add Now</button>
                            <input type="reset" class="reset radius2" value="Reset" />
                       </div>
                        
                        
                    </form>
