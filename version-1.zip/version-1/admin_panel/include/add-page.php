<?php
                    if ($_SERVER['REQUEST_METHOD']  == 'POST' AND isset($_REQUEST['SUBMIT'])) {
                        $name = mysql_real_escape_string($_REQUEST['name']);
                        $cont = mysql_real_escape_string($_REQUEST['cont']);
                        mysql_query("INSERT INTO `page`(`id`, `pagename`, `cont`) VALUES (NULL,'$name','$cont')");
                         echo '<div class="notification msgsuccess">
                                <a class="close"></a>
                                <p><b>New Page Added. <a href="page">Click</a> for manege page</b></p>
                            </div>';
                         
                        }else{
                            echo mysql_error();
                        }
                        # code...
                    ?>
                    <form  class="stdform stdform2" id="banner" method="post" action="" enctype="multipart/form-data">
                    
                            
                      
                                
                                <p>
                                    <label>Page Name</label>
                                    <span class="field"><input type="text" name="name" class="longinput"/></span>
                                </p>
                                 <p>
                                    <label>Page Name</label>
                                    <span class="field"><textarea name="cont" id="body"></textarea></span>
                                </p>
            
                            
                           
                                <p>
                                    <label></label>
                                    <span class="field">
                
                
                
                             <button type="submit" class="stdbtn btn_black" style="opacity: 1;" name="SUBMIT">Add Now</button>
                            <input type="reset" class="reset radius2" value="Reset" /></span>
                                </p>
                               
                           

                    </form>
