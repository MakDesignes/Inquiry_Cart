<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['SUBMIT'])) {
					$name=$_REQUEST['menname'];
                        $dic=$_REQUEST['pagedec'];
                        $MID=$_REQUEST['id'];
                        $query=mysql_query("UPDATE `header_menu` SET `name`='$name',`contant`='$dic' WHERE `id` = '$MID'");
                        if ($query == true) {
                         echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>YourLink Has Been Updates sucessfully. <a href="manage-links">Click</a> for manege header links</b></p>
                    </div>';

                        $ID=$MID; 
                        }else{
                            echo mysql_error();
         }
}else{
	$ID=mysql_real_escape_string($_REQUEST['ID']);
}


$get_header_record=mysql_query("SELECT * FROM `header_menu` WHERE `id`='$ID'");
$get_header_record_final=mysql_fetch_array($get_header_record);

 ?>

 <form  class="stdform stdform2" id="banner" method="post" action="" enctype="multipart/form-data">
                    
                            
                      
                                
                                <p>
                                    <label>Menu Name</label>
                                    <span class="field"><input type="text" name="menname" class="longinput" value="<?php echo $get_header_record_final['name']; ?>"/></span>
                                </p>
                                <p>
                                    <label>Menu Page contant</label>
                                    <span class="field"><textarea id="body" name="pagedec"><?php echo $get_header_record_final['contant']; ?></textarea></span>
                                </p>
                                


                           
                                <p>
                                    <label></label>
                                    <span class="field">
                
                        <input type="hidden" name='id' value="<?php echo $ID ?>"> 
                
                             <button type="submit" class="stdbtn btn_black" style="opacity: 1;" name="SUBMIT">Update Now</button>
                            <input type="reset" class="reset radius2" value="Reset" /></span>
                                </p>
                               
                           

                    </form>
