<?php 
if (isset($_REQUEST['art'])) {
   $_SESSION['artM'] = $_REQUEST['art'];
   $art = $_SESSION['artM'];
}else{
    if (isset($_SESSION['artM'])) {
        $art = $_SESSION['artM'];
    }
}
	$prds =  mysql_query("select * from products where prd_art = '$art' LIMIT 1");
	if (mysql_num_rows($prds) > 0) {
        $row = mysql_fetch_object($prds);
        $hash = $row->prd_hash;
       $id = $row->prd_id;
                $imgoneq = mysql_query("SELECT * FROM `upload_data` WHERE `USER_CODE` = '$hash' LIMIT 1");
?>
<div id="wrap" style="
    clear: both;
    width: 100%;
    height: 513px;
">
<div id="right" style="
    float: right;
">
<?php
                while($imgrow = mysql_fetch_array($imgoneq)): ?>
                      
                       <img src="../source/products/<?php echo $imgrow['FILE_NAME']; ?>" alt="">
                <?php endwhile; ?>
 </div>
 <div id="left">
<div class="contenttitle radiusbottom0">
                	<h2 class="table"><span>product Oddetail</span></h2>
</div>
<table cellpadding="0" cellspacing="0" border="1"  style="width: 64% !important;" class="stdtable">
                    <colgroup>
                        <col class="con0">
                        <col class="con1">
                        <col class="con0">
                        <col class="con1">
                        <col class="con0">
                    </colgroup>
                    <thead>
                        <tr>
                            <th>Product Name</th>
                  <th>Products Code</th>
                  <th>Products Size</th>
                  <th>Products Color</th>
                        </tr>
                    </thead>
                    <tbody>
                      <tr>
                  <td><?php echo $row->prd_name; ?></td>
                  <td><?php echo $row->prd_art; ?></td>
                  <td><?php echo $row->prd_size; ?></td>
                  <td><?php echo $row->prd_color; ?></td>
                </tr>
                    </tbody>
                </table>

       <?php } ?>
       <ul class="widgetlist" style="padding: 30px;">
                    	<li><a href="visitors">VISITORS FOR TODAY<h1 style="margin-top: 16px;"><?php echo mysql_num_rows(mysql_query("SELECT * FROM `visitors`")); ?></h1></a></li>
                    	<li><a href="">BLOCK VISITORS<h1 style="margin-top: 16px;"><?php echo mysql_num_rows(mysql_query("SELECT * FROM `blockvisitors`")); ?></h1></h1></a></li>
                    	<li><a href="manage-products" >TOTAL PRODUCTS<h1 style="margin-top: 16px;"><?php echo mysql_num_rows(mysql_query("SELECT * FROM `products`")); ?></h1></a></li>
                        <li><a href="inqueries" >TOTAL INQUERY<h1 style="margin-top: 16px;"><?php echo mysql_num_rows(mysql_query("SELECT * FROM `inquiry`")); ?></h1></a></li>
                    	<li><a href="">TOTAL SALE PRODUCTS<h1 style="margin-top: 16px;"><?php echo mysql_num_rows(mysql_query("SELECT * FROM `inquiry`")); ?></h1></a></li>
                    </ul>
       </div>
	   </div>