<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL ?>admin/source/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript" src="jquery-1.7.min.js"></script>
<script type="text/javascript" src="reCopy.js"></script>
<script type="text/javascript">
$(function(){
var removeLink = ' <a class="remove" href="#" onclick="$(this).parent().slideUp(function(){ $(this).remove() }); return false">remove</a>';
$('a.add').relCopy({ append: removeLink}); 
});
</script> 
<script type="text/javascript" src="<?php echo BASE_URL ?>admin/source/jquery.fancybox.js?v=2.1.5"></script>
<script type="text/javascript">
jQuery(document).ready(function ($) {
      $('.iframe-btn').fancybox({
              'width'   : 880,
              'height'  : 570,
              'type'    : 'iframe',
              'autoScale'   : false
      });
      
      $('.fieldID').on('change',function(){
          alert('change triggered');
      });

            //
            // Handles message from ResponsiveFilemanager
            //
            function OnMessage(e){
              var event = e.originalEvent;
               // Make sure the sender of the event is trusted
               if(event.data.sender === 'responsivefilemanager'){
                  if(event.data.field_id){
                    var fieldID=event.data.field_id;
                    var url=event.data.url;
                            $('.'+fieldID).val(url).trigger('change');
                            $.fancybox.close();

                            // Delete handler of the message from ResponsiveFilemanager
                            $(window).off('message', OnMessage);
                  }
               }
            }

          // Handler for a message from ResponsiveFilemanager
            $('.iframe-btn').on('click',function(){
              $(window).on('message', OnMessage);
            });

});
</script>
<?php 

$user_code = crc32(time());
if(isset($_FILES['files'])){
    $urlpre = htmlentities(substr(time(),2));
    $newname=date('Ymdhis');
    $prdname = $_POST['pro_name'];
    $prd_link = str_replace(' ', '-', $prdname).'-'.$urlpre;
    $artno = $_POST['art_no'];
    $productpric = $_POST['prd_price'];
    $Sorting = $_POST['sorting_order'];
    $color = $_POST['pro_color'];
    // $prdimg = $_FILES['img']['name'];
    // $prdimgtemp = $_FILES['img']['tmp_name'];
    $prdcatfe =$_POST['pro_cat'];
    $explo = explode("-", $prdcatfe);
    $prdcat = $explo[0];
    $main_ca = $explo[1];
    $prdstat = $_POST['pro_stat'];
    $pro_featur = $_POST['pro_featur'];
    $keyword = $_POST['keyword'];
    $mtdis = $_POST['mtdis'];
    $prd_dec= $_POST['prd_dec'];
    $pro_size= $_POST['pro_size'];
    $errors= array();
    $params = array(
    'constraint' => array('width' => 370, 'height' => 507)
);
    foreach($_FILES['files']['tmp_name'] as $key => $tmp_name ){
        $file_name = $key.'_'.$_FILES['files']['name'][$key]=$newname.".jpg";
        $file_size =$_FILES['files']['size'][$key];
        $file_tmp =$_FILES['files']['tmp_name'][$key];
        $file_type=$_FILES['files']['type'][$key];  
        if($file_size > 20971524546546546){
            $errors[]='File size must be less than 2 MB';
        }       
        $desired_dir="../source/products";
        $dir = $desired_dir."/big";
        $path = "$desired_dir/".$file_name;
        $desired_dir_thumb = $desired_dir.'/small/small_';
        $desired_dir_thumb_extra = $desired_dir.'/small/extrasmall_';
        if(empty($errors)==true){
            if(is_dir($desired_dir)==false){
                mkdir("$desired_dir", 0700);        // Create directory if it does not exist
            }
            if(is_dir("$desired_dir/".$file_name)== false){
                move_uploaded_file($file_tmp,"$desired_dir/".$file_name);
                // creating thembnails
                // funtion thumbnails thumbnails($path,$newwidth,$newhight,$dir,$img);
                //thumbnails($dir,370,507,$path,$img);
                // img_resize('../source/products/'.$file_name, '../source/products/cash/'.$file_name, $params);
                //end  creating thembnails
            }else{                                  // rename the file if another one exist
                $new_dir="$desired_dir/".$file_name.time();
                 rename($file_tmp,$new_dir) ;               
            }
         mysql_query("INSERT INTO `upload_data`(`ID`, `USER_CODE`, `FILE_NAME`, `FILE_SIZE`, `FILE_TYPE`) VALUES ('','$user_code','$file_name','$file_size','$file_type')");           
        }else{
                print_r($errors);
        }
    }
    if(empty($error)){
        mysql_query("INSERT INTO `products`( `prd_name`, `prd_price`, `prd_meta_key`, `prd_meta_dic`, `prd_meta_auth`, `prd_dec`, `prd_hash`, `ped_cat`, `prd_order`, `prd_stat`, `prd_featur`, `prd_link`, `prd_color`,`prd_art`,`prd_size`,`main_cat_i`) VALUES ('$prdname','$productpric','$keyword','$mtdis','','$prd_dec','$user_code','$prdcat','$Sorting','$prdstat','$pro_featur','$prd_link','$color','$artno','$pro_size','$main_ca')");
         echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>New Product Added sucessfully. <a href="manage-products">Click</a> for manage products</b></p>
                    </div>';
    }
}

?>
     <form  class="stdform stdform2" method="post" action="" enctype="multipart/form-data" id="form1">
                    
                            
                       
                            
                                <p>
                                    <label>Product Name</label>
                                    <span class="field"><input type="text" name="pro_name" class="longinput" maxlength="40" required/></span>
                                </p>
                                
                                <p>
                                    <label>Art No</label>
                                    <span class="field"><input type="text" name="art_no" class="longinput" maxlength="100" required/></span>
                                </p>
                                <p>
                                    <label>Product Price</label>
                                    <span class="field"><input type="text" name="prd_price" class="longinput" maxlength="100" required/></span>
                                <op>
                                <p>
                                    <label>Sorting Order</label>
                                    <span class="field"><select name="sorting_order" maxlength="100" required>
                                        <option value="">Choose One</option>
                                        <option value="0">0</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                        <option value="8">8</option>
                                        <option value="9">9</option>
                                        
                                    </select></span>
                                </p>
                                <p>
                                    <label>Product Color</label>
                                    <span class="field"><input type="text" name="pro_color" class="longinput" maxlength="100" required/></span>
                                </p>
                                
                                 <p>
                                    <label>Product Size</label>
                                    <span class="field"><input type="text" name="pro_size" class="longinput" maxlength="100" required/></span>
                                </p>
                                

                                <p>
                                    <label>Product Image</label>
                                    <span class="field">
                                    <span class="clone"> 
<!--                                         <input id="fieldID" type="text" value="">
                                          <a href="<?php echo BASE_URL ?>filemanager/dialog.php?type=1&field_id=fieldID" class="btn iframe-btn" type="button">Select</a> -->
                                    <input type="file" name="files[]" style="margin-bottom: 10px;" type="file" name="pro_img" class="longinput" maxlength="100" class='input'/></span>
                                    <br><a href="#" class="add" rel=".clone">Add More</a>                                 
                                    </span>
                                </p>
                                                                
                                <p>
                                    <label>Product Catagory</label>
                                    <span class="field"><select name="pro_cat" maxlength="100" required>
                                        <option value="">Choose One Catagory</option>
                                        <?php
                                        $query=mysql_query('SELECT * FROM `sub_cats`');
                                        while($queryf=mysql_fetch_array($query)){
                                        
                                        
                                        ?>
                                        <option value="<?php echo $queryf['sub_cat_id']; ?>-<?php echo $queryf['main_cat_id']; ?>"><?php echo $queryf['caption']; ?></option>
                                        <?php
                                        
                                        }
                                        ?>
                                    </select></span>
                                </p>
                                 <p>
                                    <label>Product Status
                                    </label>
                                    <span class="field"><select name="pro_stat" maxlength="100" required>
                                        <option value="0">Choose One</option>
                                        <option value="0">Not Available</option>
                                        <option value="1">Available</option>
                                    </select></span>
                                </p>
                                <p>
                                    <label>Feature Product
                                    </label>
                                    <span class="field"><select name="pro_featur" maxlength="100" required>
                                        <option value="0">Choose One</option>
                                        <option value="0">no</option>
                                        <option value="1">yes</option>
                                    </select></span>
                                </p>
                                <p>
                                    <label>Proucts Meta Keywords for seo</label>
                                    <span class="field"><input type="text" name="keyword" class="longinput" maxlength="100" required/></span>
                                </p>
                                <p>
                                    <label>Proucts Meta Discription for seo</label>
                                    <span class="field"><input type="text" name="mtdis" class="longinput" maxlength="100" required/></span>
                                </p>

                                <p>
                                    <label>Product Discription</label>
                                    <span class="field"><textarea cols="80" rows="5" class="longinput"  name="prd_dec" required></textarea></span> 
                                </p>
                                 <p>
                                    <label></label>
                                    <span class="field">
<button type="submit" class="stdbtn btn_black" style="opacity: 1;" name="demo">Add Product</button>

                            <input type="reset" class="reset radius2" value="Reset" /></span>
                                </p>
                               
                           

                    </form>