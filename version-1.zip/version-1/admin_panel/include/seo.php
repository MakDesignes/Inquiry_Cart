  <?php
                // this is a seo update script
                  if (isset($_POST['seoupdate'])) {
                  	  $id=mysql_real_escape_string($_REQUEST['id']);
                    $site_name=mysql_real_escape_string($_REQUEST['site_name']);
                    $meta_keyword=mysql_real_escape_string($_REQUEST['meta_keyword']);
                    $meta_decrap=mysql_real_escape_string($_REQUEST['meta_decrap']);
                    $meta_title=mysql_real_escape_string($_REQUEST['meta_title']);


                    $query=mysql_query("UPDATE `seo` SET `site_name`='$site_name',`meta_title`='$meta_title',`meta_keyword`='$meta_keyword',`meta_decrap`='$meta_decrap' WHERE id='$id'");
                    
                    if($query == true){

                         echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>Update data successfully</b></p>
                    </div>';
                        
                        
                    }else{
                        echo "<h1>Error! with updating data <a href='seo.php'>goback</a></h1>";
                    }
                  }
                    
                    ?>
                <form  class="stdform stdform2" method="post" >
                    
                            
                       <?php
                       $get_userv=mysql_query("SELECT * FROM `seo`");
                       while($get_user=mysql_fetch_assoc($get_userv)){
                           extract($get_user);
                       
                       ?>
            
                                <p>
                                    <label>Site name:</label>
                                    <span class="field"><input type="text" name="site_name" class="longinput" maxlength="40" value="<?php echo $site_name; ?>"/></span>
                                </p>
                                <p>
                                    <label>Meta title:</label>
                                    <span class="field"><input type="text" name="meta_title" class="longinput"  value="<?php echo $meta_title; ?>"/></span>
                                </p>
                                <p>
                                    <label>Meta keywords:</label>
                                    <span class="field"><input type="text" name="meta_keyword" class="longinput" value="<?php echo $meta_keyword; ?>"/></span>
                                </p>
                                <p>
                                    <label>Meta description:</label>
                                    <span class="field"><input type="text" name="meta_decrap" class="longinput" value="<?php echo $meta_decrap; ?>"/></span>
                                </p>
                               
                                <?php } ?>
                                <p>
                                    <input type="hidden" name="id" value="<?php echo $id; ?>"> 
                                    <label></label>
                                    <span class="field"><button type="submit" class="stdbtn btn_black" name="seoupdate" style="opacity: 1;" name="SUBMIT">Update Setting</button>
                            <input type="reset" class="reset radius2" value="Reset" /></span>
                                </p>
                               
                           

                    </form>