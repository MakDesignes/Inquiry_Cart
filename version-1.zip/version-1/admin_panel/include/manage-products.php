<?php 
if ($_SERVER['REQUEST_METHOD']  == 'POST' AND isset($_REQUEST['ORDER'])) {
                        $id = mysql_real_escape_string($_REQUEST['mid']);
                        $sorting_order = mysql_real_escape_string($_REQUEST['sorting_order']);
                        $querysort = mysql_query("UPDATE `products` SET  prd_order='$sorting_order' WHERE prd_id = '$id'") or die(mysql_error());
                        if ($querysort == true) {
                 echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>Your Sorting Order updates sucessfully</b></p>
                    </div>';
                         
                        }else{
                            echo mysql_error();
                        }
                        # code...
                    }
// end sorting order update
if ($_SERVER['REQUEST_METHOD']  == 'POST' AND isset($_REQUEST['Feature'])) {
                        $idf = mysql_real_escape_string($_REQUEST['mid']);
                        $pro_feature= mysql_real_escape_string($_REQUEST['pro_feature']);
                        $featur = mysql_query("UPDATE `products` SET  prd_featur='$pro_feature' WHERE prd_id = '$idf'") or die(mysql_error());
                        if ($featur == true) {
                 echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>Your Product feature stats change sucessfully!</b></p>
                    </div>';
                         
                        }else{
                            echo mysql_error();
                        }
                        # code...
                    }
// end featute update order update
if ($_SERVER['REQUEST_METHOD']  == 'POST' AND isset($_REQUEST['PRDSTAT'])) {
                        $id = mysql_real_escape_string($_REQUEST['mid']);
                        $prd_stat= mysql_real_escape_string($_REQUEST['pro_stat']);
                        $prd_statq = mysql_query("UPDATE `products` SET  prd_stat='$prd_stat' WHERE prd_id = '$id'") or die(mysql_error());
                        if ($prd_statq == true) {
                 echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>Your Product status change sucessfully!</b></p>
                    </div>';
                         
                        }else{
                            echo mysql_error();
                        }
                        # code...
                    }
                    // delete prduct
if ($_SERVER['REQUEST_METHOD']  == 'POST' AND isset($_REQUEST['DELPRD'])) {
                        $HIDM = mysql_real_escape_string($_REQUEST['PRDID']);
                        $prddel = del_prd($HIDM);
                        if ($prddel == true) {
                 echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>Your Product Deleted sucessfully!</b></p>
                    </div>';
                         
                        }else{
                            echo mysql_error();
                        }
                        # code...
                    }
 ?>
 
<a href="add-product"><button class="stdbtn btn_lime" style="float: right; display: block; opacity: 1;">ADD NEW PRODUCT</button></a>
 <?php
                   if(!isset($_REQUEST["catagary"])){
                                
                                $queryq=mysql_query("SELECT * FROM `products`");
                                
                                
                            }else{
                                if (empty($_REQUEST["catagary"])) {
                                    $queryq=mysql_query("SELECT * FROM `products`");
                                }else{
                                $vari=$_REQUEST["catagary"];
                                $queryq=mysql_query("SELECT * FROM `products` WHERE `ped_cat`='$vari' ");
                            }
                            }
                    $varchaq=mysql_num_rows($queryq);
                    
                    if($varchaq>0){
                   ?>
                    <div class="contenttitle radiusbottom0">
                        <h2 class="image"><span>Manage Products</span></h2>
                    </div><!--contenttitle-->
                                  <div class="tableoptions">
                    <form action="" method="post">
                    <select class="radius3" name="catagary">
                    <option value="">Select your catagory</option>
                            <?php
                            $maincats_rs = mysql_query("SELECT * FROM `sub_cats` ORDER BY RAND()");
                            while($var=mysql_fetch_array($maincats_rs)){
                            
                            ?>
                        
                        <option value="<?php echo $var['sub_cat_id']; ?>"><?php echo $var['caption']; ?></option>
                        <?php } ?>
                    </select> &nbsp;
                    <button class="radius3">Apply Filter</button>
                    </form>
                </div><!--tableoptions-->  
                    <table cellpadding="0" cellspacing="0" border="0" id="table2" class="stdtable mediatable">
                        <colgroup>
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                        </colgroup>
                        <thead>
                            <tr>
                                <td class="head0 center"><input type="checkbox" class="checkall" /></td>
                                
                                <td class="head0 center">Product image</td>
                                <td class="head1 center">Product name</td>
                                <td class="head0 center">Products catagory</td>
                                <td class="head1 center">Update Order</td>
                                <td class="head0 center">Feature Product</td>
                                <td class="head1 center">Product Status</td>
                                <td class="head0 center">Product Action</td>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        while($query=mysql_fetch_assoc($queryq)){ 
                        $unicode = $query['prd_hash'];
                      
                            ?>

                            <tr>
                                <td class="center"><input type="checkbox" /></td>
                                <td class="center">
                                <?php $img = mysql_fetch_assoc(mysql_query("SELECT * FROM `upload_data` WHERE `USER_CODE` = '$unicode' LIMIT 1"));?>
                                <img src="../source/products/<?php echo $img['FILE_NAME']; ?>" alt="" style="width:100px; height:100px;" /></td>
                        
                                <td class="center"><?php echo $query['prd_name']; ?></td>
                                <td class="center"><?php 
                                        $var=$query['ped_cat'];
                                        $submenq=mysql_query("SELECT * FROM `sub_cats` WHERE `sub_cat_id`='$var'");
                                        while($submen=mysql_fetch_array($submenq)){
                                            echo $submen['caption'];
                                            
                                        }
                                        
                                 ?></td>
                            
                                <td class="center">
                                <form  method="POST">
    <input type="text" size="2" name="sorting_order" value="<?php echo $query['prd_order']?>"  /> 
    <input type="hidden"  name="mid" value="<?php echo $query['prd_id']?>" />
    <input type="submit" name="ORDER" value="Update" style="background-color:#333333; color:#FFFFFF; width:auto; padding-left:15px; padding-right:15px;" />
    </form></td>
                                <td class="center">

                                        <form method="POST">
                                            <span class="field">
                                            <select name="pro_feature" maxlength="100" required="required">
                                        <?php $Featureprds=$query['prd_featur'];
                                        if ($Featureprds > 0) {
                                        echo '<option value="1" selected>Default: YES</option>';
                                        echo '<option value="0">NO</option>';   
                                        }else{

                                        echo '<option value="1" >YES</option>';
                                        echo '<option value="0" selected>Default: NO</option>'; 
                                        }

                                        ?>
                                       
                                    </select>
    
    <input type="hidden"  name="mid" value="<?php echo $query['prd_id']?>" />
    <input type="submit" name="Feature" value="Update" style="background-color:#333333; color:#FFFFFF; width:auto; padding-left:15px; padding-right:15px;" />
    </form>
                                </td>
                                 <td class="center">

                                        <form  method="POST">
                                            <span class="field"><select name="pro_stat" maxlength="100" required="required">
                                        <?php $Featureprds=$query['prd_stat'];
                                        if ($Featureprds > 0) {
                                        echo '<option value="1" selected>Default: ACTIVE</option>';
                                        echo '<option value="0">NO</option>';   
                                        }else{

                                        echo '<option value="1" >YES</option>';
                                        echo '<option value="0" selected>Default: NOT ACTIVE</option>'; 
                                        }

                                        ?>
                                       
                                    </select>
    
    <input type="hidden"  name="mid" value="<?php echo $query['prd_id']?>" />
    <input type="submit" name="PRDSTAT" value="Update" style="background-color:#333333; color:#FFFFFF; width:auto; padding-left:15px; padding-right:15px;" />
    </form>
                                </td>
                                <td class="center">
                                <form action="edit-product" method="post">
                                <input type="hidden" name="PRDID" value="<?php echo $query['prd_id'] ?>">
                                <input type="submit" name="PRDEDIT" value="Update" style="background-color:#333333; color:#FFFFFF; width:auto; padding-left:15px; padding-right:15px;" />
                                </form>
                                <hr>
                                <form  method="post">
                                <input type="hidden" name="PRDID" value="<?php echo $query['prd_id'] ?>">
                                <input type="submit" name="DELPRD" value="Delete" style="background-color:#333333; color:#FFFFFF; width:auto; padding-left:15px; padding-right:15px;" />
                                </form> 
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>

                    <?php } else{ echo '<h1>No Recoed Found</h1>';} ?>
