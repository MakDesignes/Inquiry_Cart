<?php 
if ($_SERVER['REQUEST_METHOD']  == 'POST' AND isset($_REQUEST['seoupdate'])) {
                        $id = mysql_real_escape_string($_REQUEST['mid']);
                        $keyword = mysql_real_escape_string($_REQUEST['keyword']);
                        $mtdis = mysql_real_escape_string($_REQUEST['mtdis']);
                        $querysort = mysql_query("UPDATE `products` SET prd_meta_dic = '$mtdis',prd_meta_key='$keyword' WHERE `prd_id` = '$id'") or die(mysql_error());
                        if ($querysort == true) {
                 echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>Your Products Seo information updates sucessfully <a href="manage-products">Click</a> for manage products</a></b></p>
                    </div>';
                         
                        }else{
                            echo mysql_error();
                        }
                        # code...
                    }
//  update info 
                    if ($_SERVER['REQUEST_METHOD']  == 'POST' AND isset($_REQUEST['imgdelet'])) {
                        $imgid = mysql_real_escape_string($_REQUEST['IMGID']);
                        $imgq = mysql_query("SELECT * FROM `upload_data` WHERE `ID` = '$imgid'");
                     if(mysql_num_rows($imgq)> 0){
                            while($imgqf = mysql_fetch_assoc($imgq)){
                            $imgqfn = $imgqf['FILE_NAME'];
                            @unlink('../source/products/'.$imgqfn);
                            @unlink('../source/products/small/small_'.$imgqfn);
                            @unlink('../source/products/small/extrasmall_'.$imgqfn);
                            }
           }
                        $querysort =  mysql_query("DELETE FROM `upload_data` WHERE `ID` = '$imgid'");
                        if ($querysort == true) {
                 echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>Your Products Seo information updates sucessfully <a href="manage-products">Click</a> for manage products</a></b></p>
                    </div>';
                         
                        }else{
                            echo mysql_error();
                        }
                        # code...
                    }
//  update info 
                    if ($_SERVER['REQUEST_METHOD']  == 'POST' AND isset($_REQUEST['upinfo'])) {
                        $id = mysql_real_escape_string($_REQUEST['mid']);
                        $pro_name = mysql_real_escape_string($_REQUEST['pro_name']);
                        $prd_price = mysql_real_escape_string($_REQUEST['prd_price']);
                        $art_no = mysql_real_escape_string($_REQUEST['art_no']);
                        $pro_color = mysql_real_escape_string($_REQUEST['pro_color']);
                        $sorting_order = mysql_real_escape_string($_REQUEST['sorting_order']);
                        $pro_size = mysql_real_escape_string($_REQUEST['pro_size']);
                        $prd_stat = mysql_real_escape_string($_REQUEST['prd_stat']);
                        $prd_featur = mysql_real_escape_string($_REQUEST['prd_featur']);
                        $prd_dec = mysql_real_escape_string($_REQUEST['prd_dec']);
                        $querysort = mysql_query("UPDATE `products` SET `prd_name`='$pro_name',`prd_price`='$prd_price',`prd_dec`='$prd_dec', `prd_order`='$sorting_order',`prd_stat`='$prd_stat',`prd_featur`='$prd_featur',`prd_color`='$pro_color',`prd_art`='$art_no',`prd_size`='$pro_size' WHERE `prd_id` = '$id'") or die(mysql_error());
                        if ($querysort == true) {
                 echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>Your Products information updates sucessfully <a href="manage-products">Click</a> for manage products</a></b></p>
                    </div>';
                         
                        }else{
                            echo mysql_error();
                        }
                        # code...
                    }
// end seo update
if ($_SERVER['REQUEST_METHOD']  == 'POST' AND isset($_REQUEST['addimg'])) {
    $user_code = $_POST['hash'];
    $errors= array();
    foreach($_FILES['files']['tmp_name'] as $key => $tmp_name ){
        $file_name = $key.'_'.$_FILES['files']['name'][$key];
        $file_size =$_FILES['files']['size'][$key];
        $file_tmp =$_FILES['files']['tmp_name'][$key];
        $file_type=$_FILES['files']['type'][$key];  
        if($file_size > 2097152){
            $errors[]='File size must be less than 2 MB';
        }       
        $desired_dir="../source/products";
        $path = "$desired_dir/".$file_name;
        $desired_dir_thumb = $desired_dir.'/small/small_';
        $desired_dir_thumb_extra = $desired_dir.'/small/extrasmall_';
        if(empty($errors)==true){
            if(is_dir($desired_dir)==false){
                mkdir("$desired_dir", 0700);        // Create directory if it does not exist
            }
            if(is_dir("$desired_dir/".$file_name)==false){
                move_uploaded_file($file_tmp,"$desired_dir/".$file_name);
                // creating thembnails
                // funtion thumbnails thumbnails($path,$newwidth,$newhight,$dir,$img);
                thumbnails($path,165,165,$desired_dir_thumb,$file_name);
                thumbnails($path,50,50,$desired_dir_thumb_extra ,$file_name);
                
                //end  creating thembnails
            }else{                                  // rename the file if another one exist
                $new_dir="$desired_dir/".$file_name.time();
                 rename($file_tmp,$new_dir) ;               
            }
         mysql_query("INSERT INTO `upload_data`(`ID`, `USER_CODE`, `FILE_NAME`, `FILE_SIZE`, `FILE_TYPE`) VALUES ('','$user_code','$file_name','$file_size','$file_type')");           
        }else{
                print_r($errors);
        }
    }
    if(empty($error)){
        
         echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>New image added sucessfully <a href="manage-products">Click</a> for manage products</a></b></p>
                    </div>';
    }
                    }
//  update info 
if (isset($_REQUEST['PRDID'])) {
   $_SESSION['PRDIDM'] = $_REQUEST['PRDID'];
   $id = $_SESSION['PRDIDM'];
}else{
    if (isset($_SESSION['PRDIDM'])) {
        $id = $_SESSION['PRDIDM'];
    }
}

                    $queryprd= mysql_query("select * from products where prd_id = '$id'");
                    $qpf = mysql_fetch_array($queryprd);
                   
                    ?>
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>

  <script>
  $(function() {
    $( "#tabs" ).tabs();
  });
  </script>

<div id="tabs">
  <ul>
    <li><a href="#tabs-1">Product Information</a></li>
    <li><a href="#tabs-2">Products Images</a></li>
    <li><a href="#tabs-3">Seo</a></li>
  </ul>
  <div id="tabs-1">
<form  class="stdform stdform2" method="post" action="" enctype="multipart/form-data" id="form1">
                    
                            
                       
                            
                                <p>
                                    <label>Product Name</label>
                                    <span class="field"><input type="text" name="pro_name" value="<?php echo $qpf['prd_name']; ?>" class="longinput" maxlength="40" required/></span>
                                </p>
                                
                                <p>
                                    <label>Art No</label>
                                    <span class="field"><input type="text" name="art_no" value="<?php echo $qpf['prd_art']; ?>" class="longinput" maxlength="100" required/></span>
                                </p>
                                <p>
                                    <label>Product Price</label>
                                    <span class="field"><input type="text" name="prd_price" value="<?php echo $qpf['prd_price']; ?>" class="longinput" required/></span>
                                <op>
                                <p>
                                    <label>Sorting Order</label>
                                    <span class="field"><select name="sorting_order" maxlength="100" required>
                                        <option value="<?php echo $qpf['prd_order']; ?>">Default : <?php echo $qpf['prd_order']; ?></option>
                                        <option value="0">0</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                        <option value="8">8</option>
                                        <option value="9">9</option>
                                        
                                    </select></span>
                                </p>
                                <p>
                                    <label>Product Color</label>
                                    <span class="field"><input value="<?php echo $qpf['prd_color']; ?>"type="text" name="pro_color" class="longinput" maxlength="100" required/></span>
                                </p>
                                
                                 <p>
                                    <label>Product Size</label>
                                    <span class="field"><input type="text" value="<?php echo $qpf['prd_size']; ?>" name="pro_size" class="longinput" maxlength="100" required/></span>
                                </p>                                                           
                                 <p>
                                    <label>Product Status
                                    </label>
                                    <span class="field"><select name="prd_stat" maxlength="100" required>
                                        <option value="<?php echo $qpf['prd_stat']; ?>">Default :  <?php echo $qpf['prd_stat']; ?></option>
                                        <option value="0">Not Available</option>
                                        <option value="1">Available</option>
                                    </select></span>
                                </p>
                                <p>
                                    <label>Feature Product
                                    </label>
                                    <span class="field"><select name="prd_featur" maxlength="100" required>
                                        <option value="<?php echo $qpf['prd_featur']; ?>">Default : <?php echo $qpf['prd_featur']; ?></option>
                                        <option value="0">no</option>
                                        <option value="1">yes</option>
                                    </select></span>
                                </p>
                                
                                <p>
                                    <label>Product Discription</label>
                                    <span class="field"><textarea cols="80" rows="5" class="longinput"  name="prd_dec" required><?php echo $qpf['prd_dec']; ?></textarea></span> 
                                </p>
                                 <p>
                                    <label></label>
                                    <span class="field">
                                    <input type="hidden" value="<?php echo $id ?>" name="mid">
<button type="submit" class="stdbtn btn_black" style="opacity: 1;" name="upinfo">Update</button>

                            <input type="reset" class="reset radius2" value="Reset" /></span>
                                </p>
                               
                           

                    </form>
  </div>
  <div id="tabs-2">
<?php $hash = $qpf['prd_hash']; ?>
<div class="contenttitle radiusbottom0">
                        <h2 class="image"><span>List Style</span></h2>
                    </div><!--contenttitle-->
                    <div class="tableoptions">
                        <form   method="post" action="" enctype="multipart/form-data" >

<input type="file" name="files[]" style="margin-bottom: 10px;" type="file" name="pro_img" class="longinput" maxlength="100" class='input' required/></span>
<input type="hidden" name="hash" value="<?php echo $hash;?>">                                  
<button type="submit" class="stdbtn btn_black" style="opacity: 1;" name="addimg">Add new</button>

                      
                           
  </form>
                    </div><!--tableoptions-->   
                    <table cellpadding="0" cellspacing="0" border="0" id="table2" class="stdtable mediatable">
                        <colgroup>
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                        </colgroup>
                        <thead>
                            <tr>
                                <td class="head0 center"><input type="checkbox" class="checkall" /></td>
                                <td class="head1 center">Thumb</td>
                                <td class="head0">Filename</td>
                                <td class="head1">Alternative</td>
                                <td class="head0">Size</td>
                                <td class="head0">Type</td>
                                <td class="head1">&nbsp;</td>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <td class="head0 center"><input type="checkbox" class="checkall" /></td>
                                <td class="head1 center">Thumb</td>
                                <td class="head0">Filename</td>
                                <td class="head1">Alternative</td>
                                <td class="head0">Size</td>
                                <td class="head1">Type</td>
                                <td class="head1">&nbsp;</td>
                            </tr>
                        </tfoot>
                        <tbody>
                        <?php $get_all_record = mysql_query("SELECT * FROM `upload_data` WHERE `USER_CODE` = '$hash'") ;
                        while ( $mainimg = mysql_fetch_assoc($get_all_record )):
                        ?>

                            <tr>
                                <td class="center"><input type="checkbox" /></td>
                                <td class="center"><a href="../source/products/<?php echo $mainimg['FILE_NAME']; ?>" class="view"><img src="../source/products/small/extrasmall_<?php echo $mainimg['FILE_NAME']; ?>" alt="" /></a></td>
                                <td><?php echo $mainimg['FILE_NAME']; ?></td>
                                <td><?php echo $mainimg['FILE_NAME']; ?></td>
                                <td><?php echo $mainimg['FILE_SIZE']; ?></td>
                                
                                <td class="center"><?php echo $mainimg['FILE_TYPE']; ?></td>
                                <td class="center">
                                <FORM method="post">
                                   <input type="hidden" value="<?php echo $mainimg['ID']; ?>" name="IMGID"> 
                                   <input type="submit" name="imgdelet" value="DELETE">
                                </FORM>
                                   
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    
                    <br /><br />  </div>
  <div id="tabs-3">
<form  class="stdform stdform2" method="post"  enctype="multipart/form-data" id="form1">
      
      <p>
                                    <label>Proucts Meta Keywords for seo</label>
                                    <span class="field"><input type="text" name="keyword" value="<?php echo $qpf['prd_meta_key']; ?>"class="longinput" maxlength="100" required/></span>
                                </p>
                                <p>
                                    <label>Proucts Meta Discription for seo</label>
                                    <span class="field"><input type="text" name="mtdis" value="<?php echo $qpf['prd_meta_dic']; ?>"class="longinput" maxlength="100" required/></span>
                                </p>
<p>
<input type="hidden" value="<?php echo $id ?>" name="mid">
                                    <label></label>
                                    <span class="field">
<button type="submit" class="stdbtn btn_black" style="opacity: 1;" name="seoupdate">Update</button>

                            <input type="reset" class="reset radius2" value="Reset" /></span>
                                </p>
  </form>
  </div>
</div>
 