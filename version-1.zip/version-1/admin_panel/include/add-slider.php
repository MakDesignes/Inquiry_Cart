<?php
if(isset($_POST['SUBMIT'])){
	
//$link=mysql_real_escape_string($_REQUEST['minid']);
$name=mysql_real_escape_string($_REQUEST['altname']);
$sorting_order=mysql_real_escape_string($_REQUEST['sorting_order']); 
$filename =$name."_".$_FILES["image"]["name"];
$path=$_FILES["image"]["tmp_name"];

if($fileuploaded=1){
    $src = imagecreatefromjpeg($path);
//list($width,$height)=getimagesize($path);
$imagesize = getimagesize($path);
$width = $imagesize[0];
$height = $imagesize[1];
$newwidth=100;
$newheight=100;

$tmp=imagecreatetruecolor($newwidth,$newheight);
imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height); 
$smallfilename = "../source/sliders/small_".$filename;
imagejpeg($tmp,$smallfilename,100);

imagedestroy($src);
imagedestroy($tmp);
$src = imagecreatefromjpeg($path);
//list($width,$height)=getimagesize($path);
$imagesize = getimagesize($path);
$width = $imagesize[0];
$height = $imagesize[1];



$newwidth=1600;
$newheight=600;

$tmp=imagecreatetruecolor($newwidth,$newheight);
imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height); 
$smallfilename = "../source/sliders/".$filename;
imagejpeg($tmp,$smallfilename,100);

imagedestroy($src);
imagedestroy($tmp);

}
$query=mysql_query("INSERT INTO `slider` (`id`, `cata`, `img`, `altname`, `sorting_order`) VALUES ('','','$filename','$name','$sorting_order')");


if($query){
    echo   '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p>Your Banner Added Sucessfully. <a href="slider">Click</a> manage slide</p>
                    </div>';
}else{
    echo mysql_error(); 
}

}
?>
<form  class="stdform stdform2" id="banner" method="post" enctype="multipart/form-data">
                    
                            
                      
                                
                                <p>
                                    <label>Banner</label>
                                    <span class="field"><input type="file" name="image"  class="longinput"/></span>
                                </p>
                                <p>
                                    <label>Alt Name</label>
                                    <span class="field"><input type="text" name="altname" class="longinput"/></span>
                                </p>
                                <p>
                                    <label>Order</label>
                                    <span class="field"><select name="sorting_order">
                                    <option value="">Select Order</option>
<?php  for($i=1;$i<=6;$i++){?>
    <option value="<?php echo $i ?>"><?php echo $i?></option>
    <?php }?>
    </select></span>
                                </p>
                           
                                <p>
                                    <label></label>
                                    <span class="field">
<button type="submit" class="stdbtn btn_black" style="opacity: 1;" name="SUBMIT">Add Banner</button>

                                        
                            <input type="reset" class="reset radius2" value="Reset" /></span>
                                </p>
                               
                           

                    </form>