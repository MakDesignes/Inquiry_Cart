<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['delete'])) {
   $HID = $_POST['MID'];
   $result = del_sub_cat($HID);
   if ($result == TRUE) {
       # code...
    $msg =  '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p>Your Sub Catagory  Deleted Sucessfully.</p>
                    </div>';
                    $id = $HID ;
   }else{
    $msg = '<b>'. mysql_error().'</b>';
    $id = $HID ;
   }
}else{
     
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['order'])) {
  $HID = $_POST['mid'];
  $ORD = $_POST['sorting_order'];
   $Updateq = mysql_query("UPDATE sub_cats set sorting_order= '$ORD' WHERE sub_cat_id = '$HID'");
   if ($Updateq == TRUE) {
       # code...
    $msg =  '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p>Your Footer Link Order Updated Sucessfully.</p>
                    </div>';
   }else{
    $msg = '<b>'. mysql_error().'</b>';
   }
}
 ?>
  <?php echo isset($msg)?$msg:'' ?>
<?php               if (isset($_SESSION['SUBCATUNIID'])) {
     $id = $_SESSION['SUBCATUNIID'] ;
    if (isset($_REQUEST['ID'])) {
        $_SESSION['SUBCATUNIID'] = mysql_real_escape_string($_REQUEST['ID']);
         $id = $_SESSION['SUBCATUNIID'] ; 
    }
                       
                    }else{
                    $_SESSION['SUBCATUNIID'] = mysql_real_escape_string($_REQUEST['ID']);
                    $id = $_SESSION['SUBCATUNIID'] ;  
                    }
                    if (!isset($id)) {
                        header('Location:404.php');
                    }

                    $maincats_rs = mysql_query("select * from main_cats where main_cat_id = '$id'");
                    $maincats = mysql_fetch_array($maincats_rs);
                    
                    ?>
                 <br clear="all" /><br />
                 <form action="add-sub-cat" method="post">
                     <input type="hidden" name="mainCat" value="<?php echo  $id  ?>">
                     <button type="submit" class="stdbtn btn_lime" style="float:right">Add New Sub Category</button>
                 </form>
                   <?php 
                   $subcats_rs = mysql_query("select * from sub_cats where main_cat_id = '$id' order by sorting_order");
                   $total_record=mysql_num_rows($subcats_rs);
                    if ($total_record == 0) {
                       echo '<h1>No sub Catagory Found!</h1>';
                    }else{
                    
                    ?>
                   
                    <div class="contenttitle radiusbottom0">
                    <h2 class="table"><span>Manege Sub Catagory</span></h2>
                    <?php
                    
                    
                    ?>
                    
                </div><!--contenttitle-->   
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                    <colgroup>
                        <col class="con0" />
                        <col class="con1" />
                        <col class="con0" />
                        <col class="con1" />
                        <col class="con0" />
                    </colgroup>
                    <thead>
                        <tr>
                            
                            <th class="head0">Sub Catagary Name</th>
                            <th class="head1">Sorting Order</th>
                            <th class="head0">Update Sorting Order</th>
                           <th class="head0">Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                    
                        <tr>
                            
                            <th class="head1"></th>
                            <th class="head0"></th>
                            <th class="head1"></th>
                            <th class="head0"></th>

                        </tr>
                    </tfoot>
                    <tbody>
                    <?php
                    
  
  while($subcats = mysql_fetch_array($subcats_rs)){
                    
                    ?>
                      <tr>  
                            <td class="center"><?php echo $subcats['caption']?></td>
                            <td class="center"><?php echo $subcats['sorting_order']?></td>
                            <td class="center"><form action="" method="post">
    <input type="text" size="2" name="sorting_order" value="<?php echo $subcats['sorting_order']?>"  /> 
    <input type="hidden"  name="mid" value="<?php echo $subcats['sub_cat_id']?>" />
    <input type="submit" name="order" value="Update" style="background-color:#333333; color:#FFFFFF; width:auto; padding-left:15px; padding-right:15px;" />
    </form></td>
                            <td class="center">
  <form action="" method="post"><input type="hidden" name="MID" value="<?php echo $subcats['sub_cat_id']?>"><input type="submit" value="DELETE" class="toggle" name="delete"></form>
                            
                             
                             </td>
                        </tr>
                        <?php } ?>
                   </tbody>
                </table>
<?php } ?>