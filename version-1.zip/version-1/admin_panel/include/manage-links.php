<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['delete'])) {
   $HID = $_POST['ID'];
   $result = mysql_query("DELETE FROM `links` WHERE `id`='$HID'");
   if ($result == TRUE) {
       # code...
    $msg =  '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p>Your Header Link Deleted Sucessfully.</p>
                    </div>';
   }else{
    $msg = '<b>'. mysql_error().'</b>';
   }
}

 ?>
 <?php echo isset($msg)?$msg:'' ?>
<ul class="maintabmenu">
                     <li class="current"><a href="manage-links" >Header Menu</a></li>
                </ul><!--maintabmenu-->
                
                <div class="content">
                   <a href="add-links"><button class="stdbtn btn_lime" style="float: right; display: block; opacity: 1;">ADD NEW HEADER LINK</button></a>
                 <?php
                    $client_site=mysql_query("SELECT * FROM `links`");
                    if(mysql_num_rows($client_site)<1){
                        echo '<center><h2>No Header Menu Link Found!</h2></center>';
                    }else{
                    
                    ?>
                    <div class="contenttitle radiusbottom0">
                    <h2 class="table"><span>new,Edit & delete header Menu</span></h2>
                </div><!--contenttitle-->   
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable dashtable">
                    <colgroup>
                        <col class="con0" />
                        <col class="con1" />
                        <col class="con0" />
                        <col class="con1" />
                        <col class="con0" />
                        <col class="con1" />
                    </colgroup>
                    <thead>
                        <tr>
                            
                            <th class="head0">ID</th>
                            <th class="head1">Links</th>
                            <th class="head0">Parent</th>
                            <th class="head1">Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                           
                            <th class="head0">ID</th>
                            <th class="head1">Links</th>
                            <th class="head0">Parent</th>
                            <th class="head1">Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                   <?php
                   while($clientsite=mysql_fetch_object($client_site)){
                       
                   
                   ?>
                        <tr>
                            <td class="center"><?php echo $clientsite->id; ?></td>
                            <td class="center"><?php echo $clientsite->linksname; ?> </td>
                            <td class="center"><?php echo $clientsite->parent; ?> </td>
                            <td class="center">
                            </form><form method="post"><input type="hidden" name="ID" value="<?php echo $clientsite->id; ?>"><input type="submit" name="delete" class="btn btn3 btn_trash" style="background-color: rgb(247, 247, 247);background: none;border: none;color: #666;" value="Delete" ></form></td>
                        </tr>
                     <?php } ?>
                    </tbody>
                </table>

                 <?php } ?>   
