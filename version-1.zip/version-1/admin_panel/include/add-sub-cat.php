<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['ADDNOW'])) {
   $caption = mysql_real_escape_string($_REQUEST['caption']);
                    $main_cata = mysql_real_escape_string($_REQUEST['main_cata']);
                    $sorting_order = mysql_real_escape_string($_REQUEST['sortind_order']);
                    if(empty($caption)){
                        echo "<h1>Please Fill The * Field</h1><br>";
                        
                    }else{

                    $nwe_man=mysql_query("INSERT INTO `sub_cats`(`sub_cat_id`, `main_cat_id`, `caption`, `heading_img`, `sorting_order`) VALUES ('','$main_cata','$caption','','$sorting_order')");
                    if($nwe_man){

                    ECHO  '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p>Your Sub Catagory Added Sucessfully.<a href="sub-cat">Click</a> for manage sub Catagory</p>
                    </div>';
                  
                    
                    }else{
                        mysql_error();
                    }
                    
                    }
}else{
    
}

 ?>
<form class="stdform" action="" method="post">
                        
                        <p>
                            <label>Sub Catagory</label>
                            <span class="field"><input type="text" name="caption" class="smallinput" required="required" /></span>
                            <small class="desc">sub  Catagory Here.</small>
                        </p>
                        <p>
                            <label>Sorting Order</label>
                            <span class="field">
                            <select name="sortind_order"  size="1">  
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                      
                                </select></span>
                            <small class="desc">Small description of this field.</small>
                            <input type="hidden" name="main_cata"  value="<?php echo  $_SESSION['SUBCATUNIID'];?>"> 
                        </p>
                        
                       
                        <p class="stdformbutton">
                            <button type="submit" class="stdbtn btn_black" style="opacity: 0.75;" name="ADDNOW">Add Now</button>
                            <input type="reset" class="reset radius2" value="Reset" />
                        </p>
                        
                        
                    </form>