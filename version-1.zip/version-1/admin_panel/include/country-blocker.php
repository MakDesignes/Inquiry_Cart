<?php 
if ($_SERVER['REQUEST_METHOD']  == 'POST' AND isset($_REQUEST['ORDER'])) {
                        $id = mysql_real_escape_string($_REQUEST['id']);
                        $stat = mysql_real_escape_string($_REQUEST['stat']);
                        $querysort = mysql_query("UPDATE `country_list` SET `stat`='$stat' WHERE `id` = '$id'") or die(mysql_error());
                        if ($querysort) {
                 echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>Your country status updates sucessfully</b></p>
                    </div>';
                         
                        }else{
                            echo mysql_error();
                        }
                        # code...
                    }
// end sorting order update
 ?>
<div class="contenttitle radiusbottom0">
                    <h2 class="table"><span>Country Blocker</span></h2>
                </div><!--contenttitle-->
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable" id="dyntable">
                    <colgroup>
                        <col class="con0" />
                        <col class="con1" />
                        <col class="con0" />
                        <col class="con1" />
                        <col class="con0" />
                    </colgroup>
                    <thead>
                       <tr>
                            <th class="head0">#</th>
                            <th class="head1">Country Name</th>
                            <th class="head0">Country Code</th>
                            <th class="head1">Block status</th>
                            <th class="head0">Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th class="head0">#</th>
                            <th class="head1">Country Name</th>
                            <th class="head0">Country Code</th>
                            <th class="head1">Block status</th>
                            <th class="head0">Action</th>
                        </tr>
                    </tfoot>
                    <?php 
                    $getcountryList = mysql_query("SELECT * FROM `country_list`");
                    while($qf = mysql_fetch_assoc($getcountryList)){
                     ?>
                
                    <tbody>
                        <tr class="gradeX">
                            <td class="center"><?php echo $qf['id']; ?></td>
                            <td><?php echo $qf['name']; ?></td>
                            <td class="center"><?php echo $qf['code']; ?></td>
                            <td class="center"><?php if($qf['stat']>0){ echo "BLOCK";}else{ echo "UN BLOCK";} ?></td>
                            <td class="center"><form  method="post">
                                <input type="hidden" name="id" value="<?php echo $qf['id']; ?>">
                                <input type="hidden" name="stat" value="<?php if($qf['stat']>0){ echo  0;}else{ echo  1;} ?>">
                                <input type="submit" name="ORDER" value="<?php if($qf['stat']>0){echo "Un Block";}else{echo "Block";} ?>" style="background-color:#333333; color:#FFFFFF; width:auto; padding-left:15px; padding-right:15px;" />
                                </form> </td>
                        </tr>
                         <?php } ?>
                    </tbody>
                </table>