
<a href="add-page"><button class="stdbtn btn_lime" style="float: right; display: block; opacity: 1;">Page</button></a>
<?php 
if (isset($_POST['delete_id'])) {
   $delete_id = mysql_real_escape_string($_POST['delete_id']);
   mysql_query("DELETE FROM `page` WHERE `id`='$delete_id'");
}

?>
 <?php 
 $queryq=mysql_query("SELECT * FROM `page`");
                    $varchaq=mysql_num_rows($queryq);
                    if($varchaq>0){
                   ?>
                    <div class="contenttitle radiusbottom0">
                        <h2 class="image"><span>Manage Page</span></h2>
                    </div><!--contenttitle-->
                                  <div class="tableoptions">
                
                </div><!--tableoptions-->  
                    <table cellpadding="0" cellspacing="0" border="0" id="table2" class="stdtable mediatable">
                        <colgroup>
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                        </colgroup>
                        <thead>
                            <tr>
                                <td class="head0 center">Id</td>
                                <td class="head1 center">Title</td>
                                <td class="head0 center">Action</td>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        while($query=mysql_fetch_object($queryq)){ 
                         ?>
                         <tr>
                             <td><?php echo $query->id; ?></td>
                             <td><?php echo $query->pagename; ?></td>
                             <td>
                                 <form action="page" method="post">
                                 <input type="hidden" name="delete_id" value="<?php echo $query->id; ?>">
                                 <button type="submit">Delete</button>
                                 </form>
                                 <hr>
                                 <form action="edit-page" method="post">
                                    <input type="hidden" name="id" value="<?php echo $query->id; ?>">
                                    <button type="submit">Edit</button>
                                 </form>
                             </td>
                         </tr>
                        <?php } ?>
                        </tbody>
                    </table>

                    <?php } else{ echo '<h1>No Recoed Found</h1>';} ?>