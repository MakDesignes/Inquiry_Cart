<?php $geoplugin = new geoPlugin();
// geting location of country
$getipdetail = mysql_query("SELECT * FROM `adminip` ORDER BY `id` DESC LIMIT 1,1");
while ($ipdel = mysql_fetch_assoc($getipdetail)) {

   @ $geoplugin->locate($ipdel['ip']);
}
?>



<strong style="float:right;"> Your last login ip address was <?php echo $geoplugin->ip ?> and your location was <?php echo $geoplugin->region ?> . <a href="get-more-detail">Click</a> for more. </strong><br clear="all" /><br />
					<ul class="widgetlist">
                    	<li><a href="visitors">VISITORS FOR TODAY<h1 style="margin-top: 16px;"><?php echo mysql_num_rows(mysql_query("SELECT * FROM `visitors`")); ?></h1></a></li>
                    	<li><a href="">BLOCK VISITORS<h1 style="margin-top: 16px;"><?php echo mysql_num_rows(mysql_query("SELECT * FROM `blockvisitors`")); ?></h1></h1></a></li>
                    	<li><a href="manage-products" >TOTAL PRODUCTS<h1 style="margin-top: 16px;"><?php echo mysql_num_rows(mysql_query("SELECT * FROM `products`")); ?></h1></a></li>
                        <li><a href="inqueries" >TOTAL INQUERY<h1 style="margin-top: 16px;"><?php echo mysql_num_rows(mysql_query("SELECT * FROM `inquiry`")); ?></h1></a></li>
                    	<li><a href="">TOTAL SALE PRODUCTS<h1 style="margin-top: 16px;"><?php echo mysql_num_rows(mysql_query("SELECT * FROM `inquiry`")); ?></h1></a></li>
                    </ul>
                    <br/>
                    <br clear="all" /><br />
               <div class="contenttitle">
                    	<h2 class="chart"><span>Simple Chart</span></h2>
                    </div><!--contenttitle-->
                    <br />
                    <div id="chartplace" style="height:300px;width:1000px"></div>
                    
                    <br />

