	<div class="contenttitle radiusbottom0">
                	<h2 class="table"><span>Your login details</span></h2>
    </div>
	<table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                    <colgroup>
                        <col class="con0">
                        <col class="con1">
                        <col class="con0">
                        <col class="con1">
                        <col class="con0">
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="head0">IP</th>
                            <th class="head1">CITY</th>
                            <th class="head0">COUNTRY</th>
                            <th class="head1">CURRENCY SYMBOL</th>
                            <th class="head0">COUNTRY CODE</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th class="head0">IP</th>
                            <th class="head1">CITY</th>
                            <th class="head0">COUNTRY</th>
                            <th class="head1">CURRENCY SYMBOL</th>
                            <th class="head0">COUNTRY CODE</th>
                        </tr>
                    </tfoot>
                    <tbody>
<?php $geoplugin = new geoPlugin();
// geting location of country
$getipdetail = mysql_query("SELECT * FROM `adminip` ORDER BY `id` DESC");
while ($ipdel = mysql_fetch_assoc($getipdetail)) {
 @$geoplugin->locate($ipdel['ip']);

	?>

                        <tr>
                            <td><?php echo $geoplugin->ip; ?></td>
                            <td class="center"><?php echo $geoplugin->city; ?></td>
                            <td class="center"><?php echo $geoplugin->countryName; ?></td>
                            <td class="center"><?php echo $geoplugin->currencySymbol ?></td>
                            <td class="center"><?php echo $geoplugin->currencyCode; ?></td>
                        </tr>
       <?php } ?>                
                    </tbody>
                </table>