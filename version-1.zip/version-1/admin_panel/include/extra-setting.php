<?php 
if (isset($_POST['SUBMIT'])) {
  $head_inc=mysql_real_escape_string($_REQUEST['head_inc']);
                    

                    $query=mysql_query("UPDATE `other_setting` SET `head_inc`='$head_inc' WHERE `oid`='1'");
                    
                    if($query == true){

                        
                         echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>Update data successfully</b></p>
                    </div>';
                        
                        
                    }else{
                        echo "<h1>Error! with updating data";
                    }
                    
}
 ?>
<form  class="stdform stdform2" method="post" >
                    
                            
                       <?php
                       $get_userv=mysql_query("SELECT * FROM `other_setting` WHERE `oid`='1'");
                       while($get_head=mysql_fetch_assoc($get_userv)){
                          
                       
                       ?>
                            
                               
                                 <p>
                                    <label>Type Your Scripts</label>
                                    <span class="field"><textarea cols="80" rows="5" class="longinput"  name="head_inc" ><?php echo $get_head['head_inc']; ?></textarea></span> 
                                </p>
                                
                                <?php } ?>
                                <p>
                                    <label></label>
                                    <span class="field">
                                    <button type="submit" class="stdbtn btn_black" style="opacity: 1;" name="SUBMIT">Update</button>

                                   
                            <input type="reset" class="reset radius2" value="Reset" /></span>
                                </p>
                               
                           

                    </form>