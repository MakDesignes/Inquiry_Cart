<?php 
if ($_SERVER['REQUEST_METHOD']  == 'POST' AND isset($_REQUEST['DEL'])) {
                        $id=mysql_real_escape_string($_REQUEST['ID']);
                        $query = mysql_query("DELETE FROM `inquiry` WHERE `id`='$id'") or die(mysql_error());
                        if ($query == true) {
                 echo '<div class="notification msgsuccess">
                        <a class="close"></a>
                        <p><b>Your inqery deleted successfully</b></p>
                    </div>';
                         
                        }else{
                            echo mysql_error();
                        }
                        # code...
                    }
 ?>
				<?php
				$inq=mysql_query("select * from inquiry");
				if(mysql_num_rows($inq) == 0 ){
					echo '<h1>No Inqueries available at this time</h1>';
					
				}else{
				?>
                   <div class="contenttitle radiusbottom0">
                    	<h2 class="image"><span>Inqueries</span></h2>
                        
                    </div><!--contenttitle-->
                    <div class="tableoptions">
                      <a href="inquery-to-excel.php"><button class="stdbtn btn_lime" >Download inqueries in CSV</button></a>  
                    </div><!--tableoptions-->
                  <table cellpadding="0" cellspacing="0" border="0" id="table2" class="stdtable mediatable">
                        <colgroup>
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                            <col class="con0" />
                            <col class="con1" />
                        </colgroup>
                        <thead>
                            <tr>
                                <td class="head0 center"></td>
                                
                                <td class="head0 center">Name</td>
                                <td class="head1 center">Phone</td>
                                <td class="head0 center">Email</td>
                                <td class="head1 center">Art#</td>
                                <td class="head0 center">dATE</td>
                                <td class="head1 center">Action</td>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
				  
				   while($rec=mysql_fetch_assoc($inq)){?>
                            <tr>
                                <td class="center"><input type="checkbox" /></td>
                                <td class="center"><?=$rec['name'];?></td>
                    <td class="center"><?=$rec['telephone'];?></td>
                      <td class="center"><a href="mailto:<?=$rec['email'];?>"><?=$rec['email'];?></a></td>
                    <td class="center"><?=$rec['prd_art'];?></td>
                    <td class="center"><?=$rec['date'];?></td>
                    <td class="center">
                    <form action="" method="post">
                        <input  type="hidden" name="ID" value="<?php echo $rec['id'];?>">
                        <input type="submit" onClick="confirm('Are you sure to delete this Inquiry')" name="DEL" value="Delete" >
                    </form>
                    </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                        </table>
                <?php } ?>
               