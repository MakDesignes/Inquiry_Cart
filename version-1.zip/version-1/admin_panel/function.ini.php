<?php
// // data base connection function here
function conn($host,$user,$pass,$db){
	$conn =  mysql_connect($host,$user,$pass) or die("enable to connect db");
	if ($conn == TRUE) {
		mysql_select_db($db);
		return $conn;
	}else{
		return false;
	}
}
/*
* mysql Login Query
*/
function login($user,$pass){
	$result  = mysql_query("SELECT * FROM `admin` WHERE `user` = '$user' AND `password` = '$pass'");
	if (mysql_num_rows($result) > 0) {
		$_SESSION['admin'] = $user;
		$_SESSION['login'] = 'login';
		return true;
	}
}
/*
* chacking user login
*/
function is_log_in(){
	if (!isset($_SESSION['admin']) || $_SESSION['login'] != 'login') {
		return false;
	}else{
		return true;
	}
}
function logout(){
	session_start();
	session_destroy();
	header('Location:'.BASE_URL.'admin_panel/');

}
function page($pge,$root){
	if ($pge != false) {
		if (!file_exists($root."/admin_panel/include/".$pge.'.php')) {
			# code...
			include('404.php');
			
		}else{
		include('include/main/header.ini.php');
		include('include/'.$pge.'.php');
		include('include/main/footer.ini.php');
	}
	}else{
		include('include/main/header.ini.php');
		include('include/dashboard.php');
		include('include/main/footer.ini.php');
	}

}


function thumbnails($path,$nwidth,$nhight,$dir,$img){
				//$uploadedfile = "$desired_dir/".$file_name;
                $src = imagecreatefromjpeg($path);
                //list($width,$height)=getimagesize($path);
                $imagesize = getimagesize($path);
                $width = $imagesize[0];
                $height = $imagesize[1];
                $newwidth=$nwidth;
                $newheight=$nwidth;
                $tmp=imagecreatetruecolor($newwidth,$newheight);
                imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height); 
                $smallfilename = $dir.$img;
                imagejpeg($tmp,$smallfilename,100);
                imagedestroy($src);
                imagedestroy($tmp);
}
function del_main_cat($HID){
	/*first chacking that if sub catagory avalable then delete sub catagory content*/
	$subcat = mysql_query("SELECT * FROM `sub_cats` WHERE `main_cat_id` = '$HID'");
	if (mysql_num_rows($subcat) > 0) {
		while ($subcatf = mysql_fetch_array($subcat)) {
			$subid = $subcatf['sub_cat_id'];
			# now finding that if product availabe?
			$prdcheck = mysql_query("SELECT * FROM `products` WHERE ped_cat = '$subid'");
			if (mysql_num_rows($prdcheck) > 0) { // if products availavle then run this loop
			while ($prdcheckf = mysql_fetch_array($prdcheck)) { // while for fetching products and checling products images
				$hash = $prdcheckf['prd_hash'];
				$image_check = mysql_query("SELECT * FROM `upload_data` WHERE `USER_CODE`='$hash'");
				if (mysql_num_rows($image_check) > 0) { // checking images
					while($imgqf = mysql_fetch_assoc($image_check)){
							$imgqfn = $imgqf['FILE_NAME'];
							@unlink('../source/products/'.$imgqfn);
							@unlink('../source/products/small/small_'.$imgqfn);
							@unlink('../source/products/small/extrasmall_'.$imgqfn);
							
							$qf = mysql_query("DELETE FROM `upload_data` WHERE `USER_CODE`='$hash'");
							if ($qf) {
								mysql_query("DELETE FROM `products` WHERE `ped_cat` = '$subid'");
								mysql_query("DELETE FROM `sub_cats` WHERE `main_cat_id` = '$HID'");
								mysql_query("DELETE FROM `main_cats` WHERE `main_cat_id`='$HID'");
								return TRUE;
							}else{
								echo "Oops! :".mysql_error();
							}
						}
				}else{
					mysql_query("DELETE FROM `products` WHERE ped_cat = '$subid'");
					mysql_query("DELETE FROM `sub_cats` WHERE `main_cat_id` = '$HID'");
					mysql_query("DELETE FROM `main_cats` WHERE `main_cat_id`='$HID'");
					return TRUE;
				}// end else
			} // end while
			// end prd if
			}else{ // end else if prduct not found
			mysql_query("DELETE FROM `sub_cats` WHERE `main_cat_id` = '$HID'");
			mysql_query("DELETE FROM `main_cats` WHERE `main_cat_id`='$HID'");
			return TRUE;
			} // end else

		}// end while fetching record using sub catagory
	}else{ // end if no subcatagory found
		mysql_query("DELETE FROM `main_cats` WHERE `main_cat_id`='$HID'");
		return TRUE;
	}
	

}
// end function of deleting main ncat

function del_sub_cat($HID){
		/*first chacking that if sub catagory avalable then delete sub catagory content*/
			$prdcheck = mysql_query("SELECT * FROM `products` WHERE ped_cat = '$HID'");
			if (mysql_num_rows($prdcheck) > 0) { // if products availavle then run this loop
			while ($prdcheckf = mysql_fetch_array($prdcheck)) { // while for fetching products and checling products images
				$hash = $prdcheckf['prd_hash'];
				$image_check = mysql_query("SELECT * FROM `upload_data` WHERE `USER_CODE`='$hash'");
				if (mysql_num_rows($image_check) > 0) { // checking images
					while($imgqf = mysql_fetch_assoc($image_check)){
							$imgqfn = $imgqf['FILE_NAME'];
							@unlink('../source/products/'.$imgqfn);
							@unlink('../source/products/small/small_'.$imgqfn);
							@unlink('../source/products/small/extrasmall_'.$imgqfn);
							
							$qf = mysql_query("DELETE FROM `upload_data` WHERE `USER_CODE`='$hash'");
							if ($qf) {
								mysql_query("DELETE FROM `products` WHERE `ped_cat` = '$HID'");
								mysql_query("DELETE FROM `sub_cats` WHERE `sub_cat_id` = '$HID'");
								return TRUE;
							}else{
								echo "Oops! :".mysql_error();
							}
						}
				}else{
					mysql_query("DELETE FROM `products` WHERE ped_cat = '$HID'");
					mysql_query("DELETE FROM `sub_cats` WHERE `sub_cat_id` = '$HID'");
					return TRUE;
				}// end else
			} // end while
			// end prd if
			}else{ // end else if prduct not found
			mysql_query("DELETE FROM `sub_cats` WHERE `sub_cat_id` = '$HID'");
			return TRUE;
			} // end else


}
/*deleting product function*/

function del_prd($HIDM){
// product delete function
			$prdcheck = mysql_query("SELECT * FROM `products` WHERE `prd_id` = '$HIDM'");
			$prdcheckf = mysql_fetch_assoc($prdcheck);
			$imgs = $prdcheckf['prd_hash'];
			// now deleting images and then delete products
			$imgq = mysql_query("SELECT * FROM `upload_data` WHERE `USER_CODE` = '$imgs'");
			if(mysql_num_rows($imgq)> 0){
			while($imgqf = mysql_fetch_assoc($imgq)){
			$imgqfn = $imgqf['FILE_NAME'];
			@unlink('../source/products/'.$imgqfn);
			@unlink('../source/products/small/small_'.$imgqfn);
			@unlink('../source/products/small/extrasmall_'.$imgqfn);
			}
			mysql_query("DELETE FROM `upload_data` WHERE `USER_CODE` = '$imgs'");
			mysql_query("DELETE FROM `products` WHERE `prd_id` = '$HIDM'");
			return TRUE;
		}else{
			mysql_query("DELETE FROM `products` WHERE `prd_id` = '$HIDM'");
			return TRUE;
		}
// end product deleting function

}
function getRealIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    {
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}	
function add_ip_indb($ip){
	$date = date('Y/m/d');
	$checkip = mysql_query("SELECT * FROM `adminip` WHERE `ip`= '$ip' AND `date` = '$date'");
	if (mysql_num_rows($checkip) > 0) {
		# code...
	}else{
		mysql_query("INSERT INTO `adminip`(`ip`, `date`) VALUES ('$ip','$date')");
	}
}	
	

?>

