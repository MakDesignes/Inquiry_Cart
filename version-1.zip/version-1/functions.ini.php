<?php 
function getRealIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    {
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}	
function add_ip_indb($ip){
	$date = date('Y/m/d');
	$checkip = mysql_query("SELECT * FROM `visitors` WHERE `cip`= '$ip' and `date` = '$date'");
	if (mysql_num_rows($checkip) > 0) {
		# code...
	}else{
		mysql_query("INSERT INTO `visitors`( `cip`, `date`) VALUES ('$ip','$date')");
	}
}
function checking_block($ip,$country){

	$qf = mysql_query("SELECT stat FROM `country_list` WHERE  `stat` = '1' AND `code` = '$country' ");
	if (mysql_num_rows($qf)>0) {
	$date = date('Y/m/d');
	$checkip = mysql_query("SELECT * FROM `blockvisitors` WHERE `bip`='$ip' AND `date`= '$date'");
	if (mysql_num_rows($checkip) > 0) {
		# code...
		return 'BLOCK';
	}else{
		mysql_query("INSERT INTO `blockvisitors`(`bip`, `date`) VALUES ('$ip','$date')");
		return 'BLOCK';
	}
	}

}	
// Function to validate against any email injection attempts
function IsInjected($str)
{
  $injections = array('(\n+)',
              '(\r+)',
              '(\t+)',
              '(%0A+)',
              '(%0D+)',
              '(%08+)',
              '(%09+)'
              );
  $inject = join('|', $injections);
  $inject = "/$inject/i";
  if(preg_match($inject,$str))
    {
    return true;
  }
  else
    {
    return false;
  }
}
function is_log_in(){
  if (!isset($_SESSION['admin']) || $_SESSION['login'] != 'login') {
    return false;
  }else{
    return true;
  }
}