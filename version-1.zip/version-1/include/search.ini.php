<div class="gap"></div>
<style>
.img-main{
width: 273px;
height: 283px;
}
</style>
<div class="container">
        <div class="row">
            <div class="span3">
                <aside class="sidebar-left hidden-phone">
                    <h4>Categories</h4>
 <div id='cssmenu'>
<ul>
<?php
        $select_main_cat=mysql_query("SELECT * FROM `main_cats` ORDER BY sorting_order");
      while($main=mysql_fetch_assoc($select_main_cat)){
      ?>
  <li class='has-sub'><a href='#'><span><?php echo $main['caption']; $main_cat_id=$main['main_cat_id']; ?></span>
<ul>
    <?php 
           $select_sub_cat=mysql_query("SELECT * FROM `sub_cats` WHERE `main_cat_id`='$main_cat_id' ORDER BY sorting_order");
          while($sub_cat=mysql_fetch_assoc($select_sub_cat)){
          ?>
      <li><a href="<?php echo $data_admin['web']; ?>products/<?php echo $sub_cat['sub_cat_id']; ?>"><?php echo $sub_cat['caption']; ?></a></li>
    <?php }  ?>
</ul>
  </li>
  <?php }  ?>
   
</ul>
</div>
                    <div class="gap gap-small"></div>
                    <h4>Search Product</h4>
                    <form class="sign-up">
                        <input type="text" class="span3" placeholder="E-mail">
                        <small class="help-block">*We never send spam</small>
                        <input type="submit" class="btn btn-primary" value="Subscribe">
                    </form>
            
                    <div class="gap gap-small"></div>
                </aside>

            </div>
            <!-- This is a side bar -->
            <div class="span9">
                <div class="row row-wrap" style="margin-left: -44px;">
                <p>
                	<span style="float:right;margin-right:10px"><?php echo " Total<b> $total_prds </b>Products <strong> |</strong> Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong>"; ?></span>
                </p><br>
								
<?php
        if ($total_prds > 0 ) {

    $i = 0;
    while ($row = mysql_fetch_object($prdrs)) {
        $hash = $row->prd_hash;
        // echo $hash;
   ?> 
<div class="span3">
            <!-- COUPON THUMBNAIL -->
                        <a class="coupon-thumb" href="<?php echo $data_admin['web']; ?>detail/<?php echo $row->prd_link; ?>">
                       <?php $img_fea = mysql_fetch_assoc(mysql_query("SELECT * FROM `upload_data` WHERE `USER_CODE` = '$hash' LIMIT 1")); ?>
                            <img class="img-main" alt="<?php echo $row->prd_name; ?>" src="<?php echo $data_admin['web']; ?>source/products/<?php echo $img_fea['FILE_NAME']; ?>?width=600">
                            <div class="coupon-inner">
                                <h5 class="coupon-title"><?php echo $row->prd_name; ?></h5>
                                <p class="coupon-desciption">Art : <?php echo $row->prd_art; ?></p>
                                <div class="coupon-meta">
                                    <div class="coupon-price">
                                        <button class="btn" onclick="" >Detail Of Product</button>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
 <!-- end product -->
<?php 
    }
        }
    
        else{
       echo '<h1 style="
    padding: 67px;
">Coming Soon</h1>';
        }?>
        
                        </div><!-- //ROW -->
                        <div class="pagination">
                        <ul>
                        <?php
          
            if ($pageNum > 1)
{
    $page = $pageNum - 1;
    $prev = " <li><a  href=\"$page\"><</a></li>";
    
    $first = " <a href=\"$self&page=1\">[First Page]</a> ";
} 
else
{
    $prev  = '  ';       // we're on page one, don't enable 'previous' link
    $first = ' '; // nor 'first page' link
    
  //  $prev  = ' [Prev] ';  
    //$first = ' [First Page] ';
}

// print 'next' link only if we're not
// on the last page
if ($pageNum < $maxPage)
{
    $page = $pageNum + 1;
    $next = " <li><a   href=\"$page\">></a>";
    
    $last = " <a href=\"$self&page=$maxPage\">[Last Page]</a> ";
} 
else
{
    $next = ' [Next] ';      // we're on the last page, don't enable 'next' link
    $last = ' [Last Page] '; // nor 'last page' link
    
    $next = ' '; 
    $last = ' ';
}

// print the page navigation link
if ($total_prds > $rowsPerPage){

echo $prev;

for($pi=1; $pi<=$maxPage; $pi++){
echo '<li><a class="page-numbers" style="margin-left:2px" href="'.$url.'products/'.$self.'/'.$pi.'">';
if($pageNum==$pi){
echo "";
echo $pi."";
}else{
echo $pi;
}

echo "</a></li>";
}

echo  $next;
 
}
            
?>
</ul>           
 </div>
                <div class="gap"></div>
            </div>
        </div>
    </div>