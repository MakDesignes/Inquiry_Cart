 <div class="gap"></div>
<div class="container">
        <div class="row">
            
            <div class="span12">
                <h3>About Company</h3>
                <p style="text-align: justify;"><?php echo $data_admin['about_you']; ?></p>
            </div>
        </div>
 

       
    </div>
     <div class="gap"></div>