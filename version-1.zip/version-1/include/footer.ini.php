 <!--
//////////////////////////////////
//////////////MAIN FOOTER////////////// 
////////////////////////////////////
-->

    <footer class="main">
        <div class="container">
            <div class="row row-wrap">
               <div class="span3">
                <h5>Links</h5>
                       <p>
                        <ul>
                            <li><a href="<?php echo $data_admin['web']; ?>">Home</a></li>
                            <li><a href="<?php echo $data_admin['web']; ?>about/">About us</a></li>
                            <li><a href="<?php echo $data_admin['web']; ?>contact/">Contact Us</a></li>
                            <li><a href="<?php echo $data_admin['web']; ?>products/all">Our Producs</a></li> 
                        </ul>
                       </p>
                    </div>
                <div class="span3">
                    <h5>Contact us</h5>
                  
                        <ul>
                            <li class="li1">Address: <?php echo $data_admin['address']; ?></li>
                            <li class="li1">Phone: <?php echo $data_admin['mobile']; ?></li>
                            <li class="li1">Ptcl: <?php echo $data_admin['fax']; ?></li>
                            <li class="li1">E-mail: <a href="mailto:<?php echo $data_admin['email']; ?>"><?php echo $data_admin['email']; ?></a></li>
                            <li class="li1">Web : <a href="http://makdesignes.wordpress.com" target="_blank">MAK Designes</a></li>
                        </ul>
                </div>
                 <div class="span3">
                        <h5>Follow</h5>
                        <!-- START TWITTER -->
                         <p>
                            <ul class="list list-social">
                                <?php if (!empty($data_admin['fb'])): ?>
        						<li>
                                    <a href="<?php echo $data_admin['fb']; ?>" class="icon-facebook box-icon" data-toggle="tooltip" title="Facebook"></a>
                                </li>
        						<?php endif ?>
        						<?php if (!empty($data_admin['tw'])): ?>
        						<li>
                                    <a href="<?php echo $data_admin['tw']; ?>" class="icon-twitter box-icon" data-toggle="tooltip" title="Twitter"></a>
                                </li>
        						<?php endif ?> 
        						<?php if (!empty($data_admin['gp'])): ?>
        					    <li>
                                    <a href="<?php echo $data_admin['gp']; ?>" class="icon-flickr box-icon" data-toggle="tooltip" title="Flickr"></a>
                                </li>
        						<?php endif ?>
        						<?php if (!empty($data_admin['pt'])): ?>
        						<li>
                                    <a href="<?php echo $data_admin['pt']; ?>" class="icon-linkedin box-icon" data-toggle="tooltip" title="Linkedin"></a>
                                </li>
        						<?php endif ?> 
        						<?php if (!empty($data_admin['fl'])): ?>
        						<li>
                                    <a href="<?php echo  $data_admin['fl']; ?>" class="icon-tumblr box-icon" data-toggle="tooltip" title="Tumblr"></a>
                                </li>
        						<?php endif ?>
                            </ul>
                        </p>
                        <!-- END TWITTER -->
                </div>
                <div class="span3">
                    <h5>News letter</h5>
           		<p style="clear:both">
                    <?php 
                    $newsq = mysql_query("SELECT * FROM `other_setting`");
                    $newsqf = mysql_fetch_assoc($newsq);
                    echo $newsqf["head_inc"];
                    
                    ?>
                    </p>
                    
                </div>
            </div>
            <p align="center">Copyright &copy; <?php echo date('Y'); ?> <b><a href="<?php echo $data_admin['web']; ?>"><?php echo $data_seo['site_name']; ?></a></b>. All Rights Reserved. Design & Developed By: <b><a href="https://makdesignes.wordpress.com/">MAK Designes</a></b></p>
        </div>
    </footer>
    </div><!-- end wrapper -->
 	 <!-- Scripts queries -->
    <script src="<?php echo $data_admin['web']; ?>source/js/jquery.js"></script>
    <script src="<?php echo $data_admin['web']; ?>source/js/boostrap.min.js"></script>
    <script src="<?php echo $data_admin['web']; ?>source/js/nivo_slider.min.js"></script>
    <script src="<?php echo $data_admin['web']; ?>source/js/countdown.min.js"></script>
    <script src="<?php echo $data_admin['web']; ?>source/js/flexnav.min.js"></script>
    <script src="<?php echo $data_admin['web']; ?>source/js/magnific.min.js"></script>
    <script src="<?php echo $data_admin['web']; ?>source/js/tweet.min.js"></script>
    <script src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
    <script src="<?php echo $data_admin['web']; ?>source/js/gmap3.min.js"></script>
    <script src="<?php echo $data_admin['web']; ?>source/js/wilto_slider.min.js"></script>
    <script src="<?php echo $data_admin['web']; ?>source/js/mediaelement.min.js"></script>
    <script src="<?php echo $data_admin['web']; ?>source/js/fitvids.min.js"></script>
    <script src="<?php echo $data_admin['web']; ?>source/js/mail.min.js"></script>
    <!-- Custom scripts -->
    <script src="<?php echo $data_admin['web']; ?>source/js/custom.js"></script>
    <script src="<?php echo $data_admin['web']; ?>source/js/switcher.js"></script>
    <script type="text/javascript">
        ( function( $ ) {
$( document ).ready(function() {
$('#cssmenu > ul > li > a').click(function() {
  $('#cssmenu li').removeClass('active');
  $(this).closest('li').addClass('active'); 
  var checkElement = $(this).next();
  if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
    $(this).closest('li').removeClass('active');
    checkElement.slideUp('normal');
  }
  if((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
    $('#cssmenu ul ul:visible').slideUp('normal');
    checkElement.slideDown('normal');
  }
  if($(this).closest('li').find('ul').children().length == 0) {
    return true;
  } else {
    return false;   
  }     
});
});
} )( jQuery );

    </script>
</body>

</html>