<?php
  $sess_id = session_id();
if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['SUBMIT'])) {
 
if(isset($_POST['address2'])){$address2 = $_POST['address2'];}else{$address2 = "";}
$name = $_POST['name'].' '.$_POST['lastname'];
$email = $_POST['email'];
$telephone = $_POST['telephone'];
$fax = $_POST['fax'];
$mobile = $_POST['mobile'];
$company = $_POST['compnyname'];
$address = $_POST['address']." ".$address2;
$city = $_POST['city'];
$date = date("Y/m/d");
$postcode = $_POST['postcode'];
$country = $_POST['country'];
if (empty($name) || empty($email) || empty($telephone) || empty($mobile) || empty($address) || empty($city) || empty($postcode) || empty($country)) {
 $msg = "Please Fill * fild for submiting inquery!";
}else{
$inqcartrsf = mysql_query("select * from inquiry_cart, products where inquiry_cart.prdid = products.prd_id AND inquiry_cart.session_id = '$sess_id'");
while($inq_cart = mysql_fetch_array($inqcartrsf)){
extract($inq_cart);
@$selected_arts .= $prd_art ." (Qty: $quantity),";
}
$clientmsg = 'Dear : '.$name;
$clientmsg .= '
Thank you for submited inquery. we will contact you asap.';
$email_body = "Hi, Following Customer had placed an inqury";
$email_body .= "Name: $name <br>
Email: $email<br>
Telephone: $telephone<br>
Mobile: $mobile<br>
Fax: $fax<br>
Comopany: $company<br>
Address: $address<br>
Postcode: $postcode<br>
Country: $country<br>
<br>
<br><br>";

$email_body .= "Following is Inquiry Detail <Br>";
$email_body .=$selected_arts;
$email_to = $data_admin['email'];
$email_subject = "New Inquiry Notice";
$headers = "MIME-Version: 1.0 \r\n";
$headers .= "Content-type: text/html; Charset=ISO-8859-1 \r\n";
$headers .= "FROM: $name <$email> \r\n";
$headers .= "Reply-To: $email \r\n";
$headers .= "cc: ";
$mail=mail($email_to, $email_subject, $email_body, $headers);
  if ($mail) {  
    mail($email, "Submited New Inquiry from ".$data_seo['site_name'], $clientmsg);
    $add_inq = mysql_query("INSERT INTO `inquiry`(`name`, `email`, `telephone`, `fax`, `mobile`, `company`, `address`, `city`, `postcode`, `country`, `date`, `prd_art`) VALUES ('$name','$email','$telephone','$fax','$mobile','$company','$address','$city','$postcode','$country','$date','$selected_arts')");
    if($add_inq == TRUE){
      $msg = '<div style="width:600px;margin:0px auto;padding:30px;" class="alert alert-success">
<button class="close" data-dismiss="alert" type="button"></button>
<strong>Well done!</strong>
Your Inquery has been submited. Thank You.Please wait you are regirect on Home page.
</div> ';
  mysql_query("DELETE FROM inquiry_cart where session_id = '$sess_id'");
  echo '<meta http-equiv="refresh" content="4; url='.$data_admin['web'].'" />';
    }
  }
}

}
 ?>
<div class="gap"></div>
<div class="container">
        <div class="row">
          <div class="span12">
             <?php
          $sess_id = session_id();
          $inq_cart_rs = mysql_query("select * from inquiry_cart, products where inquiry_cart.prdid = products.prd_id AND inquiry_cart.session_id = '$sess_id'");
          if(mysql_num_rows($inq_cart_rs)==0){
        //       echo ' <section class="envor-section envor-section-cart">
        // <div class="container">';
        //       echo "<center><h1>Your Shopping Cart Is Empty</h1></center>";
        //       echo '</div>';
          }else{
            ?>
            
<table style="transition: all 0.7s ease-in-out 0s;margin-left: -14px;" class="table table-bordered effect-fade in" data-effect="fade">
                          <thead>
                           <tr>
                             <th class="span2">Art #</th>
                              <th class="span2">Image</th>
                              <th class="span3">Product Name</th>
                              <th class="span3">Quantity</th>
                              <th class="span3">Price</th>
                              <th class="span2">Action</th>
                            </tr>
                          </thead>
                          <tbody>
     <?php
              $total_price=0;
        while($cart = mysql_fetch_array($inq_cart_rs)){
        $prd_hash = $cart['prd_hash'];
              ?>
           
                            <tr>
                            <td><b><?php echo $cart['prd_art'];?></b></td>
                              <td class="image">
                                  <?php $imgfgm = mysql_fetch_assoc(mysql_query("SELECT * FROM `upload_data` WHERE `USER_CODE` = '$prd_hash' LIMIT 1")); ?>
                              <a href="<?php echo $data_admin['web']; ?>detail/<?php echo $cart['prd_link'];?>"><img title="product" alt="product" src="<?php echo $data_admin['web']; ?>source/products/<?php echo $imgfgm['FILE_NAME']; ?>" width="60"></a></td>
                              <td class="product"><a href="<?php echo $data_admin['web']; ?>detail/<?php echo $cart['prd_link'];?>" title="<?php echo $cart['prd_name'];?>"><?php echo $cart['prd_name'];?></a> </td>
                              <td class="stock">
                              <form action="<?php echo $data_admin['web']; ?>inq_up.php" method="post">
                                 <input type="text" size="2" style="width: 48%;" value="<?php echo $cart['quantity'];?>" name="up" class="w30">
                                 <input type="hidden"  value="<?php echo $cart['prd_id'];?>"name="id" class="w30">
                                <input type="image" style="/* padding: 8px; */width: 20px;" title="Update" alt="Update" src="<?php echo $data_admin['web']; ?>source/images/update.jpg">
                    </form></td>
                              <td><?php echo $cart['prd_price'];?></td>
                              <td class="product-remove"><a href="<?php echo $data_admin['web']; ?>inq_del.php?id=<?php echo $cart['id'];?>" onclick="return confirm('Are you sure you want to delete?')"><span class="icon-trash" style="font-size: 42px;"></span></a></td>
                            
                            </tr>

              <?php
}

              ?>
           
                          </tbody>
                        </table>
          
          
          <?php } ?>
          </div>
         
    <?php echo isset($msg)?$msg:''; ?>
			            <?php 

                  $inq_cart_rs = mysql_query("select * from inquiry_cart, products where inquiry_cart.prdid = products.prd_id AND inquiry_cart.session_id = '$sess_id'");
          if(mysql_num_rows($inq_cart_rs)==0){
            echo ' <section class="envor-section envor-section-cart">
        <div class="container">';
              echo "<center><h1>Your Shopping Cart Is Empty</h1></center>";
              
          }else{
         ?>
<form  action="<?php echo $data_admin['web']; ?>checkout/"  method="post">
 <div class="span6">
                    <div class="control-group">
                      <label class="control-label" >First Name<span class="red">*</span></label>
                      <div class="controls">
                        <input type="text"class="span5"  value=""name="name" placeholder="First name * " required>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label" >Last Name<span class="red">*</span></label>
                      <div class="controls">
                        <input type="text" class="span5"  value="" name="lastname" placeholder="Last name * " required>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label" >E-Mail<span class="red">*</span></label>
                      <div class="controls">
                        <input type="email" class="span5"  value="" name="email" placeholder="Email * " required>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label" >Telephone<span class="red">*</span></label>
                      <div class="controls">
                        <input type="text" class="span5"  value="" name="telephone" placeholder="Phone # * " required>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label" >Fax</label>
                      <div class="controls">
                        <input type="text" class="span5"  value="" placeholder="Fax # " name="fax">
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label" >mobile<span class="red">*</span></label>
                      <div class="controls">
                        <input type="text" class="span5"  value="" placeholder="Mobile # * " name="mobile" required>
                    </div>
                    </div>
                  </div>
                  <div class="span6">
                    <div class="control-group">
                      <label class="control-label" >Company</label>
                      <div class="controls">
                        <input type="text" class="span5"  value="" placeholder="Company" name="compnyname">
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label" >Address 1<span class="red">*</span></label>
                      <div class="controls">
                        <input type="text" class="span5" value="" placeholder="Address * " name="address" required>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label"  >Address 2</label>
                      <div class="controls">
                        <input type="text" class="span5"  value="" placeholder="Address 2  " name="address2">
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label" >City<span class="red">*</span></label>
                      <div class="controls">
                        <input type="text" class="span5"  value=""placeholder="City * "  name="city" required>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label" >Post Code<span class="red">*</span></label>
                      <div class="controls">
                        <input type="text" class="span5"  value="" placeholder="Post Code * " name="postcode" required>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label" >Country<span class="red">*</span></label>
                      <div class="controls">
                        <select id="selectError" class="span5" name="country" required>
                          <option>Please Select Your Country</option>
                          <option value="Pakistan">Pakistan</option><option value="Australia">Australia</option><option value="Argentina">Argentina</option><option value="Belgium">Belgium</option><option value="Bolivia">Bolivia</option><option value="Brazil">Brazil</option><option value="Colombia">Colombia</option><option value="Costa Rica">Costa Rica</option><option value="Republic">Czech Republic</option><option value="Denmark">Denmark</option><option value="Dubai">Dubai</option><option value="Dominican Republic">Dominican Republic</option><option value="Egypt">Egypt</option><option value="France">France</option><option value="Germany">Germany</option><option value="Hungary">Hungary</option><option value="Iceland">Iceland</option><option value="Italy">Italy</option><option value="Iran">Iran</option><option value="Israel">Israel</option><option value="Jamaica">Jamaica</option><option value="Kazakhstan">Kazakhstan</option><option value="kuwait unitednetwork">kuwait unitednetwork</option><option value="Malaysia">Malaysia</option><option value="Mexico">Mexico</option><option value="Netherlands">Netherlands</option><option value="New Zealand">New Zealand</option><option value="Orange Nyumban">Orange Nyumbani</option><option value="PALESTINE">PALESTINE</option><option value="Portugal">Portugal</option><option value="Puerto Rico">Puerto Rico</option><option value="Russia">Russia</option><option value="Romania">Romania</option><option value="Saudi Arabia">Saudi Arabia</option><option value="Spain">Spain</option><option value="SSweden">SSweden</option><option value="Switzerland">Switzerland</option><option value="Sri Lanka">Sri Lanka</option><option value="Trinidad">Trinidad</option><option value="Tobago">Tobago</option><option value="Turkey">Turkey</option><option value="Thailand">Thailand</option><option value="United States">United States</option><option value="Indonesia">Indonesia</option><option value="United Kingdom">United Kingdom</option><option value="Venezuela">Venezuela</option><option value="Vietnam">Vietnam</option><option value="Uzbekistan">Uzbekistan</option>
                        </select>
                      </div>
                    </div>
                  
                  </div>
              </fieldset>
 <br>


					              
				   
					<button style="float:right;margin-right:20px" name="SUBMIT" type="submit" class="btn"> Submit</button>
</form> 

          <?php } ?>
		 <div class="gap"></div>
            </div>
        </div>
    </div>