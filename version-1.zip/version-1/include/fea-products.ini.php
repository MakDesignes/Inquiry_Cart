<div class="gap"></div>
<style>
.img-main{
width: 273px;
height: 283px;
}
</style>
<div class="container">
        <div class="row">
            <div class="span12">
                <div class="row row-wrap" style="margin-left: -44px;">
                <?php 
                    $ourprd = mysql_query("SELECT * FROM `products` WHERE `prd_stat`='1' and `prd_featur`=1 ORDER BY `prd_order`  LIMIT 8");
                    while ( $ourprdf = mysql_fetch_object($ourprd)):
                    $hash = $ourprdf->prd_hash;
                ?>
                    <div class="span3">
                        <!-- COUPON THUMBNAIL -->
                        <a class="coupon-thumb" href="<?php echo $data_admin['web']; ?>detail/<?php echo $ourprdf->prd_link; ?>">
                        <?php $img = mysql_fetch_assoc(mysql_query("SELECT * FROM `upload_data` WHERE `USER_CODE` = '$hash' LIMIT 1")); ?>
                            <img class="img-main" title="" alt="<?php echo $ourprdf->prd_name; ?>" src="<?php echo $data_admin['web']; ?>source/products/<?php echo $img['FILE_NAME']; ?>?width=600">
                            <div class="coupon-inner">
                                <h5 class="coupon-title"><?php echo $ourprdf->prd_name; ?></h5>
                                <p class="coupon-desciption">Art : <?php echo $ourprdf->prd_art; ?></p>
                                <div class="coupon-meta">
                                    <div class="coupon-price">
                                        <button class="btn" onclick="" >Detail Of Product</button>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- end product -->
                <?php endwhile; ?>  
                </div>
                <div class="gap"></div>
            </div>
        </div>
    </div>