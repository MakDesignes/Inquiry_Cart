<!DOCTYPE HTML>
<html>

<head>
    <title>MAK Designes - Professional Web & Graphics Designer</title>
    <!-- meta info -->
    <meta name="description" content="<?php echo $data_seo['meta_decrap']; ?>">
    <meta name="keywords" content="<?php echo $data_seo['meta_keyword']; ?>">
    <meta name="author" content="MAK Designes">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google-translate-customization" content="c5811255f956b854-5a49813cf6403f95-g376d892b2029afbe-e"></meta>
    <!-- Google fonts -->
    <!-- <link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,600' rel='stylesheet' type='text/css'> -->
    <link href='http://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>
    <!-- Bootstrap styles -->
    <link rel="stylesheet" href="<?php echo $data_admin['web']; ?>source/css/boostrap.css">
    <link rel="stylesheet" href="<?php echo $data_admin['web']; ?>source/css/boostrap_responsive.css">
    <!-- Font Awesome styles (icons) -->
    <link rel="stylesheet" href="<?php echo $data_admin['web']; ?>source/css/font_awesome.css">
    <!-- Main Template styles -->
    <link rel="stylesheet" href="<?php echo $data_admin['web']; ?>source/css/styles.css">

    <!-- IE 8 Fallback -->
    <!--[if lt IE 9]>
	<link rel="stylesheet" type="text/css" href="css/ie.css" />
<![endif]-->

    <!-- Your custom styles (blank file) -->
    <link rel="stylesheet" href="<?php echo $data_admin['web']; ?>source/css/mystyles.css">
        <link rel="stylesheet" href="<?php echo $data_admin['web']; ?>source/css/switcher.css">
    <!-- Demo Examples -->
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/pink.css" title="pink" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/teal.css" title="teal" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/gold.css" title="gold" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/downy.css" title="downy" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/atlantis.css" title="atlantis" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/red.css" title="red" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/violet.css" title="violet" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/pomegranate.css" title="pomegranate" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/violet-red.css" title="violet-red" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/mexican-red.css" title="mexican-red" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/curious-blue.css" title="curious-blue" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/orient.css" title="orient" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/jgger.css" title="jgger" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/de-york.css" title="de-york" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/blaze-orange.css" title="blaze-orange" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="<?php echo $data_admin['web']; ?>source/css/schemes/hot-pink.css" title="hot-pink" media="all" />
    <style>
    .top-area {
  position: relative;
  overflow: inherit !important;
}
   .nav {
  margin-bottom: -42px;
  /* margin-left: 0; */
  list-style: none;
  padding: 0px !important;
  background: #990000;
}
h3{
   color: #fff !important;
}
.help-block, .help-inline {
   color: #fff !important;
}
.goog-te-gadget-simple {
    background-color: rgba(255, 255, 255, 0) !important;
    border-left: none !important;
    border-top: none !important;
    border-bottom: none !important;
    border-right: none !important;
    font-size: 10pt;
    display: inline-block;
    padding-top: 1px;
    padding-bottom: 2px;
    cursor: pointer;
    zoom: 1;
}
.langu{
    /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#990000+0,000000+100 */
  background: rgb(153,0,0); /* Old browsers */
  background: -moz-linear-gradient(top,  rgba(153,0,0,1) 0%, rgba(0,0,0,1) 100%); /* FF3.6-15 */
  background: -webkit-linear-gradient(top,  rgba(153,0,0,1) 0%,rgba(0,0,0,1) 100%); /* Chrome10-25,Safari5.1-6 */
  background: linear-gradient(to bottom,  rgba(153,0,0,1) 0%,rgba(0,0,0,1) 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#990000', endColorstr='#000000',GradientType=0 ); /* IE6-9 */

 }
    </style>
    <!-- END Demo Examples -->
</head>

<body style="color:#fff !important">
	<div id="wrap">
    <header class="main">
    <div class="inner-header-top">
    	<div class="cont">
    		<ul>
    			
    			<li><i class="icon-envelope-alt"></i> <a href="mailto:<?php echo $data_admin['email']; ?>"> <?php echo $data_admin['email']; ?></a></li>
    		</ul>
    	</div>
    	<div class="langu">
    	 
<div id="google_translate_element"</div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE, multilanguagePage: true}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

    		
    	</div>
    </div>
    <div class="row-fluid" style="background:black">
		  <div class="span4">
		  <div class="logo">
		    	<img src="<?php echo $data_admin['web']; ?>makdesignes.png" style="height: 97px;width: 363px;">
		    </div>
		  </div>
		  <div class="span8">
		  	<div style="float:right;line-height: 45px;">
		  		 <a href="<?php echo $data_admin['web']; ?>checkout/">
            <?php 
      $sess_id = session_id();
       $inq_rs = mysql_query("select quantity from inquiry_cart where session_id='$sess_id'");
      $total_products = "";
      while($inq_results = mysql_fetch_array($inq_rs)){
    
        $total_products += $inq_results['quantity'];
      }
        if($total_products==1){
      // echo $total_products."  item";  
      }else if($total_products>1){
      // echo $total_products."  item(s)"; 
      }else{ ?>
      <i class="icon-shopping-cart"></i>
          <span style="color:#990000">View </span> Basket
        <?php
    }if($total_products==0){
    }else{
?>
<i class="icon-shopping-cart"></i>
<?php echo $total_products; ?> (<?php if($total_products > 1){ echo "items";}else{ echo "item";} ?>) in your cart
<?php }  ?> 
</a>
                            <form method="get" action="<?php echo $data_admin['web']; ?>search/">
                   		<input type="text" name="s"  placeholder="Sarch Product">
                   		<input type="submit" class="btn btn-primary" value="Search" style="
    margin-top: -9px;
    margin-right: 11px;
">
                    	    </form>
		  	</div>
		  </div>
	</div>
	<!-- end logo and other div -->
	<div class="nav">
   		    <div class="flexnav-menu-button" id="flexnav-menu-button">Menu</div>
                    <nav>
                        <ul class="nav nav-pills flexnav" id="flexnav" data-breakpoint="800">
                            <li><a href="<?php echo $data_admin['web']; ?>">Home</a></li>
                            <li><a href="<?php echo $data_admin['web']; ?>about/">About us</a></li>
                            <li><a href="<?php echo $data_admin['web']; ?>contact/">Contact Us</a></li>
                            <li><a href="<?php echo $data_admin['web']; ?>products/all">Our Products</a></li> 
                          
                        </ul>
                    </nav>
   	</div>
    
    </header>