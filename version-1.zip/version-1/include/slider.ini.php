<!-- TOP AREA -->
    <div class="top-area" style="float: left;">
        <!-- START BOOTSTRAP CAROUSEL -->
        <div id="my-carousel" class="carousel slide">
            <div class="carousel-inner">
                <div class="active item">
                    <img src="<?php echo $data_admin['web']; ?>source/img/img1.jpg"/>
                </div>
                <div class="item">
                    <img src="<?php echo $data_admin['web']; ?>source/img/img2.jpg" />
                </div>
            </div>
            <a class="carousel-control left" href="#my-carousel" data-slide="prev"></a>
            <a class="carousel-control right" href="#my-carousel" data-slide="next"></a>
        </div>
        <!-- END BOOTSTRAP CAROUSEL -->
    </div>
<!-- END TOP AREA -->