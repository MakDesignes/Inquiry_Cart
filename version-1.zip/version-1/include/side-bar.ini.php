<div id="sidebar" class="col-lg-3 col-md-3 col-sm-3 padbot50">
						
						<!-- CATEGORIES -->
						<div class="sidepanel widget_categories">
						  <h3>Products Categories</h3>
<ul id="leftmenu">
<?php
        $select_main_cat=mysql_query("SELECT * FROM `main_cats` ORDER BY sorting_order");
      while($main=mysql_fetch_assoc($select_main_cat)){
      ?>
  <li>
  <?php echo $main['caption']; $main_cat_id=$main['main_cat_id']; ?>
    
    <?php 
           $select_sub_cat=mysql_query("SELECT * FROM `sub_cats` WHERE `main_cat_id`='$main_cat_id' ORDER BY sorting_order");
          while($sub_cat=mysql_fetch_assoc($select_sub_cat)){
          ?>
      <ul><li><a href="<?php echo $data_admin['web']; ?>products/<?php echo $sub_cat['sub_cat_id']; ?>"><?php echo $sub_cat['caption']; ?></a></li></ul>
    <?php }  ?>
  </li>
  <?php }  ?>
</ul>


						</div><!-- //CATEGORIES -->
						
						<!-- PRICE RANGE -->
						<div class="sidepanel widget_pricefilter">
							<h3>Filter by price</h3>
							<div id="price-range" class="clearfix">
								<label for="amount">Range:</label>
								<input type="text" id="amount"/>
								<div class="padding-range"><div id="slider-range"></div></div>
							</div>
						</div><!-- //PRICE RANGE -->

					

						<!-- NEWSLETTER FORM WIDGET -->
						<div class="sidepanel widget_newsletter">
							<div class="newsletter_wrapper">
								<h3>NEWSLETTER</h3>
								<form class="newsletter_form clearfix" action="javascript:void(0);" method="get">
									<input type="text" name="newsletter" value="Enter E-mail & Get 10% off" onFocus="if (this.value == 'Enter E-mail & Get 10% off') this.value = '';" onBlur="if (this.value == '') this.value = 'Enter E-mail & Get 10% off';" />
									<input class="btn newsletter_btn" type="submit" value="Sign up & get 10% off">
								</form>
							</div>
						</div><!-- //NEWSLETTER FORM WIDGET -->
</div> 