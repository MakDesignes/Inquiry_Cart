<div class="gap"></div>
<div class="container">
<?php if($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['submit']))
{
  
  $name = $_POST['name'];
  $visitor_email = $_POST['email'];
  $art = $_POST['art'];
  // $company = $_POST['phone'];
  $subject_user = "One item Inquiry";
  $user_message = $_POST['message'];
  ///------------Do Validations-------------
  if(empty($name)||empty($visitor_email))
  {
    $errors = '<div class="alert alert-error" id="form-fail">Sorry, error occured this time sending your message</div>'; 
  }
  if(IsInjected($visitor_email))
  {
    $errors = '<div class="alert alert-error" id="form-fail">Sorry, error occured this time sending your message</div>';
  }

  
  if(empty($errors))
  {
    //send the email
    $to = $data_admin['email'];
    $subject= "New Contact us Request submit on you website";
    $from = $data_admin['email'];
    $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';    
    $body = "A user  $name submitted the contact form:\n".
    "Name: $name\n".
    "Email: $visitor_email \n".
    "subject: $subject_user \n ".
    "Message: \n ".
    "Item Art number: $art\n".
    "$user_message\n".
    "IP: $ip\n";  
    
    $headers = "From: $from \r\n";
    $headers .= "Reply-To: $visitor_email \r\n";
    
    $mail = mail($to, $subject, $body,$headers);
    if ($mail) {
    	    $msg = '<div class="alert alert-success" id="form-success">Your message has been sent successfully!</div>';
    }else{
    	    $msg = '<div class="alert alert-error" id="form-fail">Sorry, error occured this time sending your message</div>';
    }

  }
} ?>

<?php 
if (mysql_num_rows($query) > 0) {
        $row = mysql_fetch_object($query);
        $hash = $row->prd_hash;
       $id = $row->prd_id;
?>
<div class="row">
            <div class="span8">
                <!-- START NIVO SLIDER -->
                <div class="slider-wrapper theme-default">
                    
                    <?php 
                $imgoneq = mysql_query("SELECT * FROM `upload_data` WHERE `USER_CODE` = '$hash'");
                while($imgrow = mysql_fetch_array($imgoneq)): ?>
                <img data-thumb="422" title="<?php echo $row->prd_name; ?>" alt="<?php echo $row->prd_name; ?>" src="<?php echo $data_admin['web']; ?>source/products/<?php echo $imgrow['FILE_NAME']; ?>" style="width: 600px;height:600px;" width="600" height="600">
                <?php endwhile; ?>   
                   
                </div>
                <!-- END NIVO SLIDER -->
            </div>
            <style>
            .nav-tabs > li {
		  margin-bottom: 0px !important;
		}
           </style>
            <div class="span4">
           <div class="box" style="color:black !important">
                    <h4><?php echo $row->prd_name; ?></h4>
                    <p><?php echo $row->prd_dec; ?></p>
                    <ul class="list coupon-meta">
                        <li><h5><span>Art Number:</span> <?php echo $row->prd_art; ?></h5></li>
                        <li><h5><span>Price:</span> <?php echo $row->prd_price; ?></h5></li>
                        <li><h5><span>Color:</span> <?php echo $row->prd_color; ?></h5></li>
                        <li><h5><span>Size:</span> <?php echo $row->prd_size; ?></h5></li>
                    </ul>
                    <a href="<?php echo $data_admin['web']; ?>add_to_cart/<?php echo $row->prd_id; ?>" class="btn btn-primary btn-large btn-block">Send Inquiry</a>
                </div>
            </div>
        </div>
        <div class="gap gap-small"></div>
        <din class="row">
        <div class="span11">
        <?php echo isset($errors)? $errors : ""; ?>
        <?php echo isset($msg)? $msg : ""; ?>
                        <div class="tabbable">
                            <ul id="myTab" class="nav nav-tabs">
                                <li class="active"><a data-toggle="tab" href="#tab-1">Details</a>
                                </li>
                                <li><a data-toggle="tab" href="#tab-2">Information</a>
                                </li>
                                <li><a data-toggle="tab" href="#tab-3">Reviews</a>
                                </li>
                                <li><a data-toggle="tab" href="#tab-4">Quick Inquiry</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div id="tab-1" class="tab-pane fade in active"><p><?php echo $row->prd_dec; ?></p></div>
                                <div id="tab-2" class="tab-pane fade">
                                	<table style="transition: all 0.7s ease-in-out 0s;" class="table table-bordered effect-fade in" data-effect="fade">
              <thead>
                <tr>
                  <th>Product Name</th>
                  <th>Products Code</th>
                  <th>Products Size</th>
                  <th>Products Color</th>
                </tr>
              </thead>
              <tbody>

                <tr>
                  <td><?php echo $row->prd_name; ?></td>
                  <td><?php echo $row->prd_art; ?></td>
                  <td><?php echo $row->prd_size; ?></td>
                  <td><?php echo $row->prd_color; ?></td>
                </tr>
              </tbody>
                           
            </table>
                                </div>
                                <div id="tab-3" class="tab-pane fade">
                                	<div id="disqus_thread"></div>
    <script type="text/javascript">
        /* * * CONFIGURATION VARIABLES: EDIT BEFORE PASTING INTO YOUR WEBPAGE * * */
        var disqus_shortname = 'Yasir'; // required: replace example with your forum shortname

        /* * * DON'T EDIT BELOW THIS LINE * * */
        (function() {
            var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
            dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
            (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
        })();
    </script>
    <noscript>Please enable JavaScript to view the <a href="http://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
    <a href="http://disqus.com" class="dsq-brlink">comments powered by <span class="logo-disqus">Disqus</span></a>
                                </div>
                                <div id="tab-4" class="tab-pane fade">


            <div >
                <form  method="post" action="">
                    <fieldset>
                        <div class="row-fluid">
                            <label>Name</label>
                            <input class="span12" id="name" name="name" type="text" placeholder="Enter Your name here" required/>
                        </div>
                        <div class="row-fluid">
                            <label>Email</label>
                           <input name="art" type="hidden" value="<?php echo $row->prd_art; ?>" />
                            <input class="span12" id="email" name="email" type="email" placeholder="You E-mail Address" required/>
                        </div>
                        <div class="row-fluid">
                            <label>Message</label>
                           
                            <textarea class="span12" id="message" name="message" placeholder="Your message" required></textarea>
                        </div>

                        
                        <input type="submit" class="btn btn-primary" value="Send Message" name="submit" >

                    </fieldset>
                </form>
                                </div>
                            </div>
                        </div>
                    </div>
        </din>
        <div class="row-fluid">
            <div class="span10">
                <h3>Similar Products</h3>
            </div>
            
        </div>
        <div class="wilto-slide row-fluid row-wrap">
<?php 
$cat_id = $row->ped_cat; 
$ourprd = mysql_query("SELECT * FROM `products` WHERE ped_cat='$cat_id' LIMIT 4");
while ( $ourprdf = mysql_fetch_object($ourprd)):
$hash = $ourprdf->prd_hash;
?>
                    <div class="span3">
                        <!-- COUPON THUMBNAIL -->
                        <a class="coupon-thumb" href="<?php echo $data_admin['web']; ?>detail/<?php echo $ourprdf->prd_link; ?>">
                        <?php $img = mysql_fetch_assoc(mysql_query("SELECT * FROM `upload_data` WHERE `USER_CODE` = '$hash' LIMIT 1")); ?>
                            <img title="Gamer Chick" class="img-main" alt="<?php echo $ourprdf->prd_name; ?>" src="<?php echo $data_admin['web']; ?>source/products/<?php echo $img['FILE_NAME']; ?>?width=600">
                            <div class="coupon-inner">
                                <h5 class="coupon-title"><?php echo $ourprdf->prd_name; ?></h5>
                                <p class="coupon-desciption">Art : <?php echo $ourprdf->prd_art; ?></p>
                                <div class="coupon-meta">
                                    <div class="coupon-price">
                                        <button class="btn" onclick="" >Detail Of Product</button>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- end product -->    
<?php endwhile; ?>	              
                </div>

	<?php } ?>
</div>
</div>
<div class="gap"></div>