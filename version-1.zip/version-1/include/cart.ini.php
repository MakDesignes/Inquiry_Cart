<div class="gap"></div>
<div class="container">
        <div class="row">
            <div class="span12">
					      <?php
          $sess_id = session_id();
          $inq_cart_rs = mysql_query("select * from inquiry_cart, products where inquiry_cart.prdid = products.prd_id AND inquiry_cart.session_id = '$sess_id'");
          if(mysql_num_rows($inq_cart_rs)==0){
              echo ' <section class="envor-section envor-section-cart">
        <div class="container">';
              echo "<center><h1>Your Shopping Cart Is Empty</h1></center>";
              echo '</div>';
          }else{
          	?>
						
<table style="transition: all 0.7s ease-in-out 0s;margin-left: -14px;" class="table table-bordered effect-fade in" data-effect="fade">
                          <thead>
                           <tr>
                             <th class="span2">Art #</th>
                              <th class="span2">Image</th>
                              <th class="span3">Product Name</th>
                              <th class="span3">Quantity</th>
                              <th class="span3">Price</th>
                              <th class="span2">Action</th>
                            </tr>
                          </thead>
                          <tbody>
     <?php
              $total_price=0;
        while($cart = mysql_fetch_array($inq_cart_rs)){
        $prd_hash = $cart['prd_hash'];
              ?>
           
                            <tr>
                            <td><b><?php echo $cart['prd_art'];?></b></td>
                              <td class="image">
                                  <?php $imgfgm = mysql_fetch_assoc(mysql_query("SELECT * FROM `upload_data` WHERE `USER_CODE` = '$prd_hash' LIMIT 1")); ?>
                              <a href="<?php echo $data_admin['web']; ?>detail/<?php echo $cart['prd_link'];?>"><img title="product" alt="product" src="<?php echo $data_admin['web']; ?>source/products/<?php echo $imgfgm['FILE_NAME']; ?>" width="60"></a></td>
                              <td class="product"><a href="<?php echo $data_admin['web']; ?>detail/<?php echo $cart['prd_link'];?>" title="<?php echo $cart['prd_name'];?>"><?php echo $cart['prd_name'];?></a> </td>
                              <td class="stock">
                              <form action="<?php echo $data_admin['web']; ?>inq_up.php" method="post">
                                 <input type="text" size="2" style="width: 48%;" value="<?php echo $cart['quantity'];?>" name="up" class="w30">
                                 <input type="hidden"  value="<?php echo $cart['prd_id'];?>"name="id" class="w30">
                                <input type="image" style="/* padding: 8px; */width: 20px;" title="Update" alt="Update" src="<?php echo $data_admin['web']; ?>source/images/update.jpg">
                    </form></td>
                              <td><?php echo $cart['prd_price'];?></td>
                              <td class="product-remove"><a href="<?php echo $data_admin['web']; ?>inq_del.php?id=<?php echo $cart['id'];?>" onclick="return confirm('Are you sure you want to delete?')"><span class="icon-trash" style="font-size: 42px;"></span></a></td>
                            
                            </tr>

              <?php
}

              ?>
           
                          </tbody>
                        </table>

					
					
					<?php } ?>
							<a class="btn active" href="<?php echo $data_admin['web']; ?>checkout/" >Check out</a>
							<a class="btn active" href="<?php echo $data_admin['web']; ?>" >Continue shopping</a>
 <div class="gap"></div>
            </div>
        </div>
    </div>