<!-- //////////////////////////////////
//////////////PAGE CONTENT///////////// 
////////////////////////////////////-->
    <div class="container" style="padding: 30px;">
        <div class="row row-wrap">
            <div class="span6">
                <!-- GOOGLE MAP -->
                <div class="gmap" id="gmap"></div>
            </div>
            	<?php if($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['submit']))
{
  
  $name = $_POST['name'];
  $visitor_email = $_POST['email'];
  // $company = $_POST['phone'];
  $subject_user = "contact us for submited";
  $user_message = $_POST['message'];
  ///------------Do Validations-------------
  if(empty($name)||empty($visitor_email))
  {
    $errors = '<div class="alert alert-error" id="form-fail">Sorry, error occured this time sending your message</div>'; 
  }
  if(IsInjected($visitor_email))
  {
    $errors = '<div class="alert alert-error" id="form-fail">Sorry, error occured this time sending your message</div>';
  }

  
  if(empty($errors))
  {
    //send the email
    $to = $data_admin['email'];
    $subject= "New Contact us Request submit on you website";
    $from = $data_admin['email'];
    $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';    
    $body = "A user  $name submitted the contact form:\n".
    "Name: $name\n".
    "Email: $visitor_email \n".
    "subject: $subject_user \n ".
    "Message: \n ".
    "$user_message\n".
    "IP: $ip\n";  
    
    $headers = "From: $from \r\n";
    $headers .= "Reply-To: $visitor_email \r\n";
    
    $mail = mail($to, $subject, $body,$headers);
    if ($mail) {
    	    $msg = '<div class="alert alert-success" id="form-success">Your message has been sent successfully!</div>';
    }else{
    	    $msg = '<div class="alert alert-error" id="form-fail">Sorry, error occured this time sending your message</div>';
    }

  }
} ?>

            <div class="span3">
                <form  method="post" action="<?php echo $data_admin['web']; ?>contact/">
                    <fieldset>
                        <div class="row-fluid">
                            <label>Name</label>
                            <input class="span12" id="name" name="name" type="text" placeholder="Enter Your name here" required/>
                        </div>
                        <div class="row-fluid">
                            <label>Email</label>
                           
                            <input class="span12" id="email" name="email" type="email" placeholder="You E-mail Address" required/>
                        </div>
                        <div class="row-fluid">
                            <label>Message</label>
                           
                            <textarea class="span12" id="message" name="message" placeholder="Your message" required></textarea>
                        </div>
                        <?php echo isset($errors)? $errors : ""; ?>
						<?php echo isset($msg)? $msg : ""; ?>
                        
                        <input type="submit" class="btn btn-primary" value="Send Message" name="submit" >

                    </fieldset>
                </form>
            </div>
            <div class="span3">
                <h5>Contact Info</h5>
                <p><?php echo substr($data_admin['about_you'], 0, 600); ?></p>
                <ul class="list">
                    <li><i class="icon-map-marker"></i> <?php echo $data_admin['address']; ?></li>
                    <li><i class="icon-phone"></i> Phone: <?php echo $data_admin['mobile']; ?></li>
                    <li><i class="icon-phone"></i> Fax: <?php echo $data_admin['fax']; ?></li>
                    <li><i class="icon-envelope"></i> E-mail: <a href="mailto:<?php echo $data_admin['email']; ?>"><?php echo $data_admin['email']; ?></a></a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="gap gap-small"></div>
    </div>


    <!-- //////////////////////////////////
//////////////END PAGE CONTENT///////// 
////////////////////////////////////-->
