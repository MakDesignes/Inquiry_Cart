<?php include'admin_panel/config.ini.php'; 
include'functions.ini.php'; 
$ip = getRealIpAddr();
add_ip_indb($ip);
include'admin_panel/sdk/geoplugin.class/geoplugin.class.php';
@$geoplugin = new geoPlugin();
@$geoplugin->locate($ip);
if (is_log_in() == true) {
  # code...
}else{
$country =  $geoplugin->countryCode;
$var = checking_block($ip,$country);
if($var == 'BLOCK'){
  include'errors/access_denied_infected.html';
  die();
}
}
// }
// if(
//         !gethostbyaddr($_SERVER['REMOTE_ADDR'])
//         || gethostbyaddr($_SERVER['REMOTE_ADDR']) == "."
//         || !$_SERVER['HTTP_ACCEPT_ENCODING']
//         || $_SERVER['HTTP_X_FORWARDED_FOR']
//         || $_SERVER['HTTP_X_FORWARDED']
//         || $_SERVER['HTTP_FORWARDED_FOR']
//         || $_SERVER['HTTP_VIA']
//         || $_SERVER['HTTP_FORWARDED']
//         || $_SERVER['HTTP_CLIENT_IP']
//         || $_SERVER['HTTP_FORWARDED_FOR_IP']
//         || $_SERVER['VIA']
//         || $_SERVER['X_FORWARDED_FOR']
//         || $_SERVER['FORWARDED_FOR']
//         || $_SERVER['X_FORWARDED FORWARDED']
//         || $_SERVER['CLIENT_IP']
//         || $_SERVER['FORWARDED_FOR_IP']
//         || $_SERVER['HTTP_PROXY_CONNECTION']
//         || in_array($_SERVER['REMOTE_PORT'], array(8080,80,6588,8000,3128,553,554))
//         || @fsockopen($_SERVER['REMOTE_ADDR'], 80, $errno, $errstr, 0)
//         || !$_SERVER['HTTP_CONNECTION']
//     )
//     {
//         include'errors/access_denied_infected.html';
//     die();
//     }
//     else
//     {
        
//     }
if (!isset($_REQUEST['id'])) {
    @header('Location:'.$data_admin_panel['web']);
}else{
$id = mysql_real_escape_string($_REQUEST['id']);
$sub_cats_rs = mysql_query("select * from sub_cats where sub_cat_id='$id'") or die(mysql_error());
$sub_cats = mysql_fetch_array($sub_cats_rs);
$cur_sub_cat_caption = $sub_cats['caption'];
$cur_main_cat_id = $sub_cats['main_cat_id'];
$cur_main_cat_rs = mysql_query("select * from main_cats where main_cat_id='$cur_main_cat_id'");
$cur_main_cats = mysql_fetch_assoc($cur_main_cat_rs);
$url = $data_admin['web'];
//-----------------------------------------------
//PAGING STARTS FROM HERE
//-----------------------------------------------
// how many rows to show per page

$rowsPerPage =12;
$productsPerRow = 2;
// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
    $pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;

// how many rows we have in database
if ($id == "all") {
	$prdrs=mysql_query("Select * from products");
}else{
	$prdrs=mysql_query("Select * from products where ped_cat='$id'");
}
$numrows=mysql_num_rows($prdrs);
$total_prds=$numrows;
// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);
if($maxPage==0) {
$maxPage=1;
}else{
$maxPage=$maxPage;
}

$self = "$id";
if ($id == "all") {
$prdrs=mysql_query("Select * from products  LIMIT $offset, $rowsPerPage");
}else{
$prdrs=mysql_query("Select * from products where ped_cat='$id' ORDER BY prd_order LIMIT $offset, $rowsPerPage");
}
include'include/header.ini.php'; 
include'include/slider.ini.php';
include'include/products.ini.php';
include'include/footer.ini.php';
} 
?>