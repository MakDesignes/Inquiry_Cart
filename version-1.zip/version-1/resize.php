<?php
//indicate which file to resize (can be any type jpg/png/gif/etc...)
$img = $_REQUEST['img'];
include 'include/smart_resize_image.function.php';
$params = array(
    'constraint' => array('width' => 300, 'height' => 300)
);
@img_resize('source/products/'.$img, 'source/products/cash/'.$img, $params);
echo "<img src='source/products/cash/".$_REQUEST['img']."'>";