<?php include'admin_panel/config.ini.php'; 
include'functions.ini.php'; 
$ip = getRealIpAddr();
add_ip_indb($ip);
include'admin_panel/sdk/geoplugin.class/geoplugin.class.php';
@$geoplugin = new geoPlugin();
@$geoplugin->locate($ip);
if (is_log_in() == true) {
  # code...
}else{
$country =  $geoplugin->countryCode;
$var = checking_block($ip,$country);
if($var == 'BLOCK'){
  include'errors/access_denied_infected.html';
  die();
}
}
// }
// if(
//         !gethostbyaddr($_SERVER['REMOTE_ADDR'])
//         || gethostbyaddr($_SERVER['REMOTE_ADDR']) == "."
//         || !$_SERVER['HTTP_ACCEPT_ENCODING']
//         || $_SERVER['HTTP_X_FORWARDED_FOR']
//         || $_SERVER['HTTP_X_FORWARDED']
//         || $_SERVER['HTTP_FORWARDED_FOR']
//         || $_SERVER['HTTP_VIA']
//         || $_SERVER['HTTP_FORWARDED']
//         || $_SERVER['HTTP_CLIENT_IP']
//         || $_SERVER['HTTP_FORWARDED_FOR_IP']
//         || $_SERVER['VIA']
//         || $_SERVER['X_FORWARDED_FOR']
//         || $_SERVER['FORWARDED_FOR']
//         || $_SERVER['X_FORWARDED FORWARDED']
//         || $_SERVER['CLIENT_IP']
//         || $_SERVER['FORWARDED_FOR_IP']
//         || $_SERVER['HTTP_PROXY_CONNECTION']
//         || in_array($_SERVER['REMOTE_PORT'], array(8080,80,6588,8000,3128,553,554))
//         || @fsockopen($_SERVER['REMOTE_ADDR'], 80, $errno, $errstr, 0)
//         || !$_SERVER['HTTP_CONNECTION']
//     )
//     {
//         include'errors/access_denied_infected.html';
//     die();
//     }
//     else
//     {
        
//     }
include'include/header.ini.php'; 
include'include/slider.ini.php';
include'include/cart.ini.php';
include'include/footer.ini.php'; 
?>