<?php
include_once('admin_panel/config.ini.php');
$session_id = session_id();
$prdid = mysql_real_escape_string($_REQUEST['id']);
$quantity = 1;
$check_inq = mysql_query("select * from inquiry_cart where prdid='$prdid' AND session_id = '$session_id'");
if(mysql_num_rows($check_inq)>0){
mysql_query("UPDATE inquiry_cart SET quantity=quantity+$quantity WHERE prdid='$prdid' AND session_id = '$session_id'");
}else{
$cur_prds_rs = mysql_query("select * from products where prd_id='$prdid'");
$cur_prds = mysql_fetch_array($cur_prds_rs);
extract($cur_prds);
mysql_query("INSERT INTO inquiry_cart(session_id, prdid, quantity) VALUES('$session_id', '$prd_id', '$quantity')") or die(mysql_error());
}
@header('Location:'.BASE_URL.'cart/'); 
?>
