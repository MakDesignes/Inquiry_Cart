<?php
include_once('admin_panel/config.ini.php');
$session_id = session_id();
$id = mysql_real_escape_string($_REQUEST['id']);
$quantaty = mysql_real_escape_string($_REQUEST['up']);

$query=mysql_query("UPDATE `inquiry_cart` SET `quantity`='$quantaty' WHERE prdid='$id' AND session_id = '$session_id'") or die(mysql_error());
if($query == true){
@header('Location: '.$_SERVER['HTTP_REFERER']);
}else{
}


?>