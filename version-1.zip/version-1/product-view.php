<?php include'admin_panel/config.ini.php'; 
include'functions.ini.php'; 
$ip = getRealIpAddr();
add_ip_indb($ip);
include'admin_panel/sdk/geoplugin.class/geoplugin.class.php';
@$geoplugin = new geoPlugin();
@$geoplugin->locate($ip);
if (is_log_in() == true) {
  # code...
}else{
$country =  $geoplugin->countryCode;
$var = checking_block($ip,$country);
if($var == 'BLOCK'){
  include'errors/access_denied_infected.html';
  die();
}
}
// }
// if(
//         !gethostbyaddr($_SERVER['REMOTE_ADDR'])
//         || gethostbyaddr($_SERVER['REMOTE_ADDR']) == "."
//         || !$_SERVER['HTTP_ACCEPT_ENCODING']
//         || $_SERVER['HTTP_X_FORWARDED_FOR']
//         || $_SERVER['HTTP_X_FORWARDED']
//         || $_SERVER['HTTP_FORWARDED_FOR']
//         || $_SERVER['HTTP_VIA']
//         || $_SERVER['HTTP_FORWARDED']
//         || $_SERVER['HTTP_CLIENT_IP']
//         || $_SERVER['HTTP_FORWARDED_FOR_IP']
//         || $_SERVER['VIA']
//         || $_SERVER['X_FORWARDED_FOR']
//         || $_SERVER['FORWARDED_FOR']
//         || $_SERVER['X_FORWARDED FORWARDED']
//         || $_SERVER['CLIENT_IP']
//         || $_SERVER['FORWARDED_FOR_IP']
//         || $_SERVER['HTTP_PROXY_CONNECTION']
//         || in_array($_SERVER['REMOTE_PORT'], array(8080,80,6588,8000,3128,553,554))
//         || @fsockopen($_SERVER['REMOTE_ADDR'], 80, $errno, $errstr, 0)
//         || !$_SERVER['HTTP_CONNECTION']
//     )
//     {
//         include'errors/access_denied_infected.html';
//     die();
//     }
//     else
//     {
        
//     }

if (!isset($_REQUEST['prdid'])) {
   @header('Loation:'.BASE_URL.'errors/404.php');
}else{
    $prdid = mysql_real_escape_string($_REQUEST['prdid']);
    $query = mysql_query("SELECT * FROM `products` WHERE `prd_id`='$prdid'");
    if (mysql_num_rows($query) > 0) {
        $row = mysql_fetch_object($query);
        $hash = $row->prd_hash;
       $id = $row->prd_id;
?>
<div class="tover_view_page element_fade_in">
	<div class="tover_view_header clearfix">
		<p>Quick view</p>
		<a id="tover_view_page_close" href="javascript:void(0);">Close<i>X</i></a>
	</div>
	
	<div class="clearfix">
		<div class="tovar_view_fotos clearfix">
			<div id="slider1" class="flexslider">
				<ul class="slides">
			 <?php 
                $imgoneq = mysql_query("SELECT * FROM `upload_data` WHERE `USER_CODE` = '$hash'");
                $imgq = mysql_query("SELECT * FROM `upload_data` WHERE `USER_CODE` = '$hash'");
				 while($imgrow = mysql_fetch_array($imgoneq)): 
			 ?>
				<li><a href="javascript:void(0);" ><img src="<?php echo $data_admin_panel['web']; ?>source/products/<?php echo $imgrow['FILE_NAME']; ?>"></a></li>
			<?php endwhile; ?>
				</ul>
			</div>

		</div>
		
		<div class="tovar_view_description">
			<div class="tovar_view_title"><?php echo $row->prd_name; ?></div>
			<div class="tovar_article">Color : <?php echo $row->prd_color; ?></div>
			<div class="clearfix tovar_brend_price">
				<div class="pull-left tovar_brend">Art : <?php echo $row->prd_art; ?></div>
				<div class="pull-right tovar_view_price"><?php echo $row->prd_price; ?></div>
			</div>
			<div class="tovar_view_btn">

				<a class="add_bag" href="<?php echo $data_admin_panel['web']; ?>add_to_cart/<?php echo $row->prd_id; ?>" ><i class="fa fa-shopping-cart"></i>Add to bag</a>
				
			</div>
			<div class="tovar_shared clearfix">
				<p>Share item with friends</p>
				<ul>
					<li><a class="facebook" href="javascript:void(0);" ><i class="fa fa-facebook"></i></a></li>
					<li><a class="twitter" href="javascript:void(0);" ><i class="fa fa-twitter"></i></a></li>
					<li><a class="linkedin" href="javascript:void(0);" ><i class="fa fa-linkedin"></i></a></li>
					<li><a class="google-plus" href="javascript:void(0);" ><i class="fa fa-google-plus"></i></a></li>
					<li><a class="tumblr" href="javascript:void(0);" ><i class="fa fa-tumblr"></i></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<?php } }  ?>